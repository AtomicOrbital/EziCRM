package com.dx.isecure.common.web.swagger;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenAPIConfig {
    @Value("${spring.swagger.title:ISecure}")
    private String title;

    @Value("${spring.swagger.description:ISecure API}")
    private String description;

    @Value("${spring.swagger.version:1.0}")
    private String version;

    @Bean
    public OpenAPI myOpenAPI() {
        Info info = new Info()
                .title(title)
                .version(version)
                .description(description);

        return new OpenAPI().info(info);
    }
}
