package com.dx.isecure.common.web.utils.validator;

import com.dx.isecure.common.web.utils.validator.annotation.DateRange;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.lang.reflect.Field;
import java.time.LocalDate;

public class DateRangeValidator implements ConstraintValidator<DateRange, Object> {
    private String startField;
    private String endField;

    @Override
    public void initialize(DateRange constraintAnnotation) {
        this.startField = constraintAnnotation.startField();
        this.endField = constraintAnnotation.endField();
    }

    @Override
    public boolean isValid(Object object, ConstraintValidatorContext context) {
        try {
            Field startFieldObj;
            try {
                startFieldObj = object.getClass().getDeclaredField(startField);
                startFieldObj.setAccessible(true);
            } catch (NoSuchFieldException e) {
                context.buildConstraintViolationWithTemplate("Start field '" + startField + "' not found")
                        .addConstraintViolation();
                return false;
            }
            LocalDate startDate = (LocalDate) startFieldObj.get(object);

            Field endFieldObj;
            try {
                endFieldObj = object.getClass().getDeclaredField(endField);
                endFieldObj.setAccessible(true);
            } catch (NoSuchFieldException e) {
                context.buildConstraintViolationWithTemplate("End field '" + endField + "' not found")
                        .addConstraintViolation();
                return false;
            }
            LocalDate endDate = (LocalDate) endFieldObj.get(object);

            if (startDate == null || endDate == null) {
                return true;
            }

            if (!endDate.isAfter(startDate)) {
                context.disableDefaultConstraintViolation();
                context.buildConstraintViolationWithTemplate(context.getDefaultConstraintMessageTemplate())
                        .addPropertyNode(endField)
                        .addConstraintViolation();
                return false;
            }
            return true;
        } catch (IllegalAccessException e) {
            context.buildConstraintViolationWithTemplate("Cannot access field: " + e.getMessage())
                    .addConstraintViolation();
            return false;
        } catch (Exception e) {
            context.buildConstraintViolationWithTemplate("Unexpected error: " + e.getMessage())
                    .addConstraintViolation();
            return false;
        }
    }
}
