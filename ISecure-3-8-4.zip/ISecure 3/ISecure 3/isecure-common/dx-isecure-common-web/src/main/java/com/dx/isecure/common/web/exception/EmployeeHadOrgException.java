package com.dx.isecure.common.web.exception;

import com.dx.isecure.common.web.exception.common.BusinessException;
import com.dx.isecure.common.web.exception.common.ServiceError;

import java.util.LinkedHashMap;
import java.util.List;

public class EmployeeHadOrgException extends BusinessException {

  public EmployeeHadOrgException(List<Integer> inactiveEmployeeIds) {
    super(ServiceError.EMPLOYEE_HAD_ORG,null, buildParams(inactiveEmployeeIds));
  }

  private static LinkedHashMap<String, Object> buildParams(List<Integer> inactiveEmployeeIds) {
    LinkedHashMap<String, Object> params = new LinkedHashMap<>();
    params.put("inactiveEmployeeIds", inactiveEmployeeIds);
    return params;
  }
}

