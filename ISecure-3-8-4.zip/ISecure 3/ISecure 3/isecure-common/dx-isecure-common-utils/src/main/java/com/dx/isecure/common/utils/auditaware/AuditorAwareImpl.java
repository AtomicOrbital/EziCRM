package com.dx.isecure.common.utils.auditaware;

import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Optional;

public class AuditorAwareImpl implements AuditorAware<String> {

    public AuditorAwareImpl() {
    }

    @Override
    public Optional<String> getCurrentAuditor() {
        var actOpt = Optional.ofNullable(SecurityContextHolder.getContext())
                .map(SecurityContext::getAuthentication)
                .map(Authentication::getPrincipal)
                .map(principal -> {
                    if (principal instanceof UserDetails userDetails ) {
                        return userDetails.getUsername();
                    } else {
                        return "system";
                    }
                });
        if(actOpt.isEmpty()) {
            //generate by system, no security context
            actOpt = Optional.of("unknown");
        }
        return actOpt;
    }
}
