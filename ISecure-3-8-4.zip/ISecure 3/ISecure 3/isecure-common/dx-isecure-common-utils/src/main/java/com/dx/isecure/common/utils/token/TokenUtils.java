package com.dx.isecure.common.utils.token;

import com.google.common.base.Strings;
import com.google.common.net.HttpHeaders;
import jakarta.servlet.http.HttpServletRequest;

public class TokenUtils {

    public static String getTokenFromRequest(HttpServletRequest req) {
        String authHeader = req.getHeader(HttpHeaders.AUTHORIZATION);

        if (Strings.nullToEmpty(authHeader).trim().isEmpty()) {
            return null;
        }

        String[] parts = authHeader.split(" ");
        if (parts.length != 2 || !"Bearer".equals(parts[0])) {
            return null;
        }

        return parts[1];
    }

}
