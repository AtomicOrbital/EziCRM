package com.dx.isecure.common.utils.fake_data;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
