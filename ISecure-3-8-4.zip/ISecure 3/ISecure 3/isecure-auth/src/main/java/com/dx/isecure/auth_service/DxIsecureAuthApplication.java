package com.dx.isecure.auth_service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@Slf4j
@SpringBootApplication(scanBasePackages = {"com.*"})
public class DxIsecureAuthApplication {
    @Value("spring.datasource.url")
    private static String url;

    public static void main(String[] args) {
        log.error(url);
        SpringApplication.run(DxIsecureAuthApplication.class, args);
    }

}
