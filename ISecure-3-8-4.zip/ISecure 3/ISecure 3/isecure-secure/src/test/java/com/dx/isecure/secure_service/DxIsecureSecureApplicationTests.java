package com.dx.isecure.secure_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DxIsecureSecureApplicationTests {

    @Test
    void contextLoads() {
    }

}
