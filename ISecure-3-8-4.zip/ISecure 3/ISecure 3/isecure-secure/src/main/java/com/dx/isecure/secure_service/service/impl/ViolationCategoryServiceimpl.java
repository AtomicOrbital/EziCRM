package com.dx.isecure.secure_service.service.impl;

import com.dx.isecure.common.web.exception.common.BusinessException;
import com.dx.isecure.common.web.exception.common.ServiceError;
import com.dx.isecure.common.web.utils.MappingHelper;
import com.dx.isecure.common.web.utils.constant.State;
import com.dx.isecure.secure_service.dto.request.SecurityStandardRequest;
import com.dx.isecure.secure_service.dto.response.SecurityStandardResponse;
import com.dx.isecure.secure_service.dto.response.ViolationCategoryParentResponse;
import com.dx.isecure.secure_service.dto.response.ViolationCategoryResponse;
import com.dx.isecure.secure_service.dto.response.ViolationItemResponse;
import com.dx.isecure.secure_service.entity.ViolationCategory;
import com.dx.isecure.secure_service.entity.ViolationItem;
import com.dx.isecure.secure_service.entity.constant.SecurityStandardType;
import com.dx.isecure.secure_service.entity.constant.Severity;
import com.dx.isecure.secure_service.repository.ViolationCategoryRepository;
import com.dx.isecure.secure_service.repository.ViolationItemRepository;
import com.dx.isecure.secure_service.service.ViolationCategoryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class ViolationCategoryServiceimpl implements ViolationCategoryService {
    private final ViolationCategoryRepository violationCategoryRepository;
    private final ViolationItemRepository violationItemRepository;
    private final MappingHelper mappingHelper;

    @Override
    public List<ViolationCategoryResponse> getAllViolationCategories() {
        List<ViolationCategory> violationCategories = violationCategoryRepository.findAll();
        return violationCategories.stream().map(violationCategory -> mappingHelper.map(violationCategory, ViolationCategoryResponse.class)).collect(Collectors.toList());
    }

    @Override
    public List<ViolationCategoryParentResponse> getAllViolationCategoriesWithItems(String keyword) {
        List<Object[]> result;

        if (StringUtils.isBlank(keyword)) {
            result = violationCategoryRepository.searchByKeyword("");
        } else {
            result = violationCategoryRepository.searchByKeyword(keyword);
        }

        List<ViolationCategoryParentResponse> responseList = new ArrayList<>();
        Map<Integer, ViolationCategoryParentResponse> categoryMap = new HashMap<>();

        for (Object[] row : result) {

            Integer categoryId = (Integer) row[0];
            String categoryCode = (String) row[1];
            String categoryName = (String) row[2];
            String categoryStatus = (String) row[3];
            Integer itemId = (Integer) row[4];
            String itemCode = (String) row[5];
            String itemName = (String) row[6];
            String severity = (String) row[7];
            String minusPointsRule = (String) row[8];
            String definition = (String) row[9];
            String itemStatus = (String) row[10];

            if (!categoryMap.containsKey(categoryId)) {
                ViolationCategoryParentResponse categoryResponse = new ViolationCategoryParentResponse();
                categoryResponse.setId(categoryId);
                categoryResponse.setCode(categoryCode);
                categoryResponse.setName(categoryName);
                categoryResponse.setStatus(categoryStatus);
                categoryResponse.setChildren(new ArrayList<>());
                categoryMap.put(categoryId, categoryResponse);
            }

            if (itemId != null) {
                ViolationItemResponse itemResponse = new ViolationItemResponse();
                itemResponse.setId(itemId);
                itemResponse.setCode(itemCode);
                itemResponse.setName(itemName);
                itemResponse.setSeverity(severity);
                itemResponse.setMinusPointsRule(minusPointsRule);
                itemResponse.setDefinition(definition);
                itemResponse.setStatus(itemStatus);
                categoryMap.get(categoryId).getChildren().add(itemResponse);
            }
        }

        responseList.addAll(categoryMap.values());
        return responseList;

    }

    @Override
    public SecurityStandardResponse createSecurityStandard(SecurityStandardRequest request) {
        if (SecurityStandardType.CATEGORY.name().equalsIgnoreCase(request.getType())) {
            return createViolationCategory(request);
        } else if (SecurityStandardType.ITEM.name().equalsIgnoreCase(request.getType())) {
            return createViolationItem(request);
        } else {
            throw new BusinessException(ServiceError.INVALID_INPUT, null, null);
        }
    }

    @Transactional
    @Override
    public SecurityStandardResponse createViolationCategory(SecurityStandardRequest request) {
        // check code, name, status
        if (StringUtils.isBlank(request.getCode()) || StringUtils.isBlank(request.getStatus())) {
            throw new BusinessException(ServiceError.REQUIRED_CODE_AND_NAME, null, null);
        }
        if (StringUtils.isBlank(request.getStatus())) {
            throw new BusinessException(ServiceError.REQUIRED_VIOLATION_CATEGORY, null, null);
        }

        Optional<ViolationCategory> existingCat =
                violationCategoryRepository.findByCodeOrName(request.getCode(), request.getName());
        if (existingCat.isPresent()) {
            throw new BusinessException(ServiceError.DUPLICATE_ENTRY, null, null);
        }

        ViolationCategory category = new ViolationCategory();
        category.setCode(request.getCode());
        category.setName(request.getName());
        category.setStatus(State.valueOf(request.getStatus()));
        violationCategoryRepository.save(category);

        // mappging to dto
        SecurityStandardResponse response = mappingHelper.map(category, SecurityStandardResponse.class);
        response.setType(SecurityStandardType.CATEGORY.name());
        // if not found children
        if (response.getChildren() == null) {
            response.setChildren(new ArrayList<>());
        }
        return response;
    }

    @Transactional
    @Override
    public SecurityStandardResponse createViolationItem(SecurityStandardRequest securityStandardRequest) {
        // check choose parent
        if (securityStandardRequest.getViolationCategoryId() == null) {
            throw new BusinessException(ServiceError.REQUIRED_VIOLATION_CATEGORY, null, null);
        }

        // check duplicate code and name
        Optional<ViolationItem> violationItemOptional = violationItemRepository.findByCodeOrName(securityStandardRequest.getCode(), securityStandardRequest.getName());
        if (violationItemOptional.isPresent()) {
            throw new BusinessException(ServiceError.DUPLICATE_ENTRY, null, null);
        }

        ViolationCategory category = violationCategoryRepository.findById(securityStandardRequest.getViolationCategoryId()).orElseThrow(() -> new BusinessException(ServiceError.ENTITY_NOT_FOUND, null, null));

        // list minus point
        List<Integer> minusPointRule = normalizeMinusPoints(securityStandardRequest.getMinusPoints());

        ViolationItem violationItem = mappingHelper.map(securityStandardRequest, ViolationItem.class);
        violationItem.setViolationCategory(category);
        violationItem.setName(securityStandardRequest.getName());
        violationItem.setCode(securityStandardRequest.getCode());
        violationItem.setStatus(State.valueOf(securityStandardRequest.getStatus()));
        violationItem.setSeverity(Severity.valueOf(securityStandardRequest.getSeverity()));
        violationItem.setMinusPointsRule(minusPointRule.stream().map(String::valueOf).collect(Collectors.joining(",")));
        violationItem = violationItemRepository.save(violationItem);

        // after create, load list violation item of violation category
        List<ViolationItem> childrenItems = violationItemRepository.findByViolationCategoryId(category.getId());
        List<ViolationItemResponse> children = mappingHelper.mapList(childrenItems, ViolationItemResponse.class);

        // mappging to dto
        SecurityStandardResponse response = mappingHelper.map(violationItem, SecurityStandardResponse.class);
        response.setType(SecurityStandardType.ITEM.name());
        if (children == null) {
            response.setChildren(new ArrayList<>());
        } else {
            response.setChildren(children);
        }
        return response;
    }

    private List<Integer> normalizeMinusPoints(List<Integer> minusPoints) {
        if (minusPoints == null || minusPoints.isEmpty()) {
            throw new BusinessException(ServiceError.MINUS_POINT_REQUIRED, null, null);
        }

        // if list has at less than 5
        while (minusPoints.size() < 5) {
            minusPoints.add(0);
        }

        // List has at least one element that has no negative value
        minusPoints = minusPoints.stream().map(point -> (point == null || point < 0) ? 0 : Math.max(point, 0)).collect(Collectors.toList());

        // If there is a subsequent violation but there was no previous violation
        int totalPoints = minusPoints.get(0);
        for (int i = 1; i < minusPoints.size(); i++) {
            if (minusPoints.get(i) > 0 && minusPoints.get(i - 1) == 0) {
                LinkedHashMap<String, Object> params = new LinkedHashMap<>();
                params.put("firstOffense", i + 1);
                params.put("secondOffense", i);
                throw new BusinessException(ServiceError.NO_SECOND_OFFENSE_ALLOWED, null, params);
            }
            totalPoints += minusPoints.get(i);
        }

        if (totalPoints > 100) {
            throw new BusinessException(ServiceError.INVALID_INPUT, null, null);
        }
        return minusPoints;
    }
}
