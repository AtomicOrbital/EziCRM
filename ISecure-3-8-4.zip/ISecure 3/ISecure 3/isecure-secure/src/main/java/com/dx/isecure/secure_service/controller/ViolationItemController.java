package com.dx.isecure.secure_service.controller;

import com.dx.isecure.common.web.response.Response;
import com.dx.isecure.common.web.response.ResponseUtils;
import com.dx.isecure.secure_service.service.ViolationItemService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
@RequestMapping("/violation-items")
@CrossOrigin("*")
public class ViolationItemController {
    private final ViolationItemService violationItemService;

    @Operation(summary = "Get violation category in period")
    @GetMapping("/categories")
    public ResponseEntity<Response> getViolationCategoriesByPeriod(@RequestParam(name = "periodId", required = false) Integer periodId) {
        return ResponseUtils.ok(violationItemService.getViolationCategoriesByPeriod(periodId));
    }

    @Operation(summary = "Get violation items by category in period")
    @GetMapping("/by-category")
    public ResponseEntity<Response> getViolationItemsByCategory(
            @RequestParam(name = "periodId", required = false) Integer periodId,
            @RequestParam(name = "categoryId") Integer categoryId) {
        return ResponseUtils.ok(violationItemService.getViolationItemsByCategory(periodId, categoryId));
    }
}
