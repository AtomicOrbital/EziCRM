package com.dx.isecure.secure_service.service;

import com.dx.isecure.secure_service.dto.ViolationCategoryDto;
import com.dx.isecure.secure_service.dto.ViolationItemDto;

import java.util.List;

public interface ViolationItemService {
    List<ViolationCategoryDto> getViolationCategoriesByPeriod(Integer periodId);

    List<ViolationItemDto> getViolationItemsByCategory(Integer periodId, Integer categoryId);
}
