package com.dx.isecure.secure_service.entity;

import com.dx.isecure.common.utils.auditaware.AuditEntity;
import jakarta.persistence.*;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "VIOLATION")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Violation extends AuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "EMPLOYEE_SECURITY_ID")
    private EmployeeSecurity employeeSecurity;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "VIOLATION_ITEM_ID")
    private ViolationItem violationItem;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "NTH_VIOLATION")
    private Integer nthViolation;

    @Column(name = "MINUS_POINTS")
    private Integer minusPoints;

    @Column(name = "FILE_GROUP_ID", length = 36)
    private String fileGroupId;
}
