package com.dx.isecure.secure_service.repository;

import com.dx.isecure.secure_service.entity.OrgEmployee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface OrgEmployeeRepository extends JpaRepository<OrgEmployee, Integer> {

    @Query(value = "FROM OrgEmployee org_e WHERE org_e.employee.id = :employeeId AND org_e.organization.id = :orgId AND org_e.timeLeft IS NULL")
    Optional<OrgEmployee> getByEmployeeAndOrg(@Param("employeeId") Integer employeeId,
                                              @Param("orgId") Integer orgId);

    @Query("SELECT org_e.employee.id FROM OrgEmployee org_e " +
            "WHERE org_e.employee.id IN :employeeIds " +
            "AND org_e.timeLeft IS NULL " +
            "AND org_e.organization.id <> :orgId")
    List<Integer> findAssignedEmployeeIds(@Param("employeeIds") List<Integer> employeeIds, @Param("orgId") Integer orgId);

    @Modifying
    @Query("UPDATE OrgEmployee org_e SET org_e.deletedAt = :deletedAt, org_e.timeLeft = :timeLeft WHERE org_e.employee.id IN :employeeIds")
    void updateDeletedAtByEmployeeIds(@Param("deletedAt") Instant deletedAt,
                                      @Param("timeLeft") LocalDate timeLeft,
                                      @Param("employeeIds") List<Integer> employeeIds);

    @Query(value = "SELECT * FROM ORG_EMPLOYEE org_e " +
            "WHERE org_e.EMPLOYEE_ID = (:employeeId) " +
            "AND org_e.TIME_JOIN <= (:violationTime) " +
            "AND ((org_e.TIME_LEFT IS NULL AND (:violationTime) >= org_e.TIME_JOIN) " +
                "OR ((:violationTime) BETWEEN org_e.TIME_JOIN AND org_e.TIME_LEFT))", nativeQuery = true)
    Optional<OrgEmployee> getInPeriodByEmployeeViolation(Instant violationTime, Integer employeeId);

    @Query(value = "FROM OrgEmployee org_e " +
            "WHERE org_e.employee.id = (:employeeId) " +
            "AND org_e.timeLeft IS NULL")
    Optional<OrgEmployee> getInCurrentPeriodByEmployee(Integer employeeId);

}
