package com.dx.isecure.secure_service.service.impl;

import com.dx.isecure.common.web.exception.EntityNotFoundException;
import com.dx.isecure.common.web.utils.MappingHelper;
import com.dx.isecure.secure_service.dto.ViolationCategoryDto;
import com.dx.isecure.secure_service.dto.ViolationItemDto;
import com.dx.isecure.secure_service.entity.Period;
import com.dx.isecure.secure_service.entity.ViolationCategory;
import com.dx.isecure.secure_service.entity.ViolationItem;
import com.dx.isecure.secure_service.repository.PeriodRepository;
import com.dx.isecure.secure_service.repository.ViolationCategoryRepository;
import com.dx.isecure.secure_service.repository.ViolationItemRepository;
import com.dx.isecure.secure_service.service.ViolationItemService;
import com.dx.isecure.secure_service.util.BusinessUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.internal.Pair;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class ViolationItemServiceImpl implements ViolationItemService {
    private final ViolationItemRepository violationItemRepository;
    private final ViolationCategoryRepository violationCategoryRepository;
    private final PeriodRepository periodRepository;
    private final MappingHelper mappingHelper;

    @Override
    public List<ViolationCategoryDto> getViolationCategoriesByPeriod(Integer periodId) {
        Period period = resolvePeriod(periodId);

        List<ViolationCategory> categoryDtoList = Boolean.TRUE.equals(BusinessUtil.isCurrentPeriod(period))
                ? violationCategoryRepository.findAll()
                : violationCategoryRepository.getCategoryInPastPeriod(period.getId());
        return mappingHelper.mapList(categoryDtoList, ViolationCategoryDto.class);
    }

    @Override
    public List<ViolationItemDto> getViolationItemsByCategory(Integer periodId, Integer categoryId) {
        Period period = resolvePeriod(periodId);
        boolean isCurrentPeriod = Boolean.TRUE.equals(BusinessUtil.isCurrentPeriod(period));

        Optional<ViolationCategory> categoryOptional = isCurrentPeriod
                ? violationCategoryRepository.findById(categoryId)
                : violationCategoryRepository.getCategoryInPastPeriodById(period.getId(), categoryId);
        ViolationCategory category = categoryOptional
                .orElseThrow(() -> new EntityNotFoundException(
                        ViolationCategory.class.getSimpleName(),
                        categoryId.toString()
                ));

        List<ViolationItem> violationItems = isCurrentPeriod
                ? violationItemRepository.findAllByCategoryI(category.getId())
                : violationItemRepository.getItemInPastPeriodByCategory(period.getId(), category.getId());

        return mappingHelper.mapList(violationItems, ViolationItemDto.class);
    }

    private Period createDefaultPeriod() {
        Pair<LocalDate, LocalDate> dateRange = BusinessUtil.getDateRangeFromSpecificDate(LocalDate.now());
        Period newPeriod = Period.builder()
                .periodStartDate(dateRange.getLeft())
                .periodEndDate(dateRange.getRight())
                .build();
        return periodRepository.save(newPeriod);
    }

    private Period resolvePeriod(Integer periodId) {
        if (periodId == null) {
            return periodRepository.findBySpecificDate(LocalDate.now())
                    .orElseGet(this::createDefaultPeriod);
        }
        return periodRepository.findById(periodId)
                .orElseThrow(() -> new EntityNotFoundException(Period.class.getSimpleName(), periodId.toString()));
    }
}
