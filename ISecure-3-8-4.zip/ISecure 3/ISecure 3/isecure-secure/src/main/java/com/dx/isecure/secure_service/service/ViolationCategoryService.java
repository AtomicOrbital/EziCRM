package com.dx.isecure.secure_service.service;

import com.dx.isecure.secure_service.dto.request.SecurityStandardRequest;
import com.dx.isecure.secure_service.dto.response.SecurityStandardResponse;
import com.dx.isecure.secure_service.dto.response.ViolationCategoryParentResponse;
import com.dx.isecure.secure_service.dto.response.ViolationCategoryResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ViolationCategoryService {
    List<ViolationCategoryResponse> getAllViolationCategories();
    List<ViolationCategoryParentResponse> getAllViolationCategoriesWithItems(String keyword);
    SecurityStandardResponse createSecurityStandard(SecurityStandardRequest request);
    SecurityStandardResponse createViolationCategory(SecurityStandardRequest request);
    SecurityStandardResponse createViolationItem(SecurityStandardRequest securityStandardRequest);
}
