package com.dx.isecure.secure_service.dto.response;

import lombok.Data;

import java.util.List;

@Data
public class ViolationCategoryParentResponse {
    private Integer id;
    private String code;
    private String name;
    private String status;
    private List<ViolationItemResponse> children;

}
