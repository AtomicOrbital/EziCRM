package com.dx.isecure.secure_service.entity;

import com.dx.isecure.common.utils.auditaware.AuditEntity;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.UUID;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "SECURITY_DOCUMENT")
@Data
public class SecurityDocument extends AuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "TITLE")
    private String title;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "VIEW_COUNT")
    private Integer viewCount;

    @Column(name = "FILE_GROUP_ID")
    private UUID fileGroupId;
}