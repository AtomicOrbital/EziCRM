package com.dx.isecure.secure_service.entity.constant;

import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

@Getter
public enum Severity {
    LOW(1, "LOW"),
    MEDIUM(2, "MEDIUM"),
    HIGH(3, "HIGH");

    Severity(int code, String str) {
        this.code = code;
        this.str = str;
    }

    private static final Map<String, Severity> SEVERITY_MAP = new HashMap<>();

    static {
        for (Severity e : values()) {
            SEVERITY_MAP.put(e.getStr(), e);
        }
    }

    private final int code;
    private final String str;

    public static Severity getByStr(String str) {
        return SEVERITY_MAP.get(str);
    }
}
