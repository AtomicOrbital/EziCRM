package com.dx.isecure.secure_service.entity;

import com.dx.isecure.common.utils.auditaware.AuditEntity;
import com.dx.isecure.common.web.utils.constant.State;
import com.dx.isecure.secure_service.entity.constant.Severity;
import jakarta.persistence.*;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "VIOLATION_ITEM")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ViolationItem extends AuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "CODE")
    private String code;

    @Column(name = "NAME")
    private String name;

    @Column(name = "SEVERITY")
    @Enumerated(EnumType.STRING)
    private Severity severity;

    @Column(name = "STATUS")
    @Enumerated(EnumType.STRING)
    private State status;

    @Column(name = "MINUS_POINTS_RULE")
    private String minusPointsRule;

    @Column(name = "DEFINITION")
    private String definition;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "VIOLATION_CATEGORY_ID")
    private ViolationCategory violationCategory;
}