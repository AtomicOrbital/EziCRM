package com.dx.isecure.secure_service.service;

import com.dx.isecure.common.web.request.PagingReq;
import com.dx.isecure.secure_service.dto.request.CheckNthViolationReq;
import com.dx.isecure.secure_service.dto.request.RegisterViolationReq;
import com.dx.isecure.secure_service.dto.request.ViolationCriteria;
import com.dx.isecure.secure_service.dto.response.CheckNthViolationRes;
import com.dx.isecure.secure_service.dto.response.ViolationDetailRes;
import com.dx.isecure.secure_service.dto.response.ViolationListRes;
import org.springframework.data.domain.Page;

public interface ViolationService {
    CheckNthViolationRes checkNthSameViolation(CheckNthViolationReq checkNthViolationReq);

    Integer registerViolation(RegisterViolationReq registerViolationReq);

    Page<ViolationListRes> getViolationList(ViolationCriteria violationCriteria, PagingReq pagingReq);

    ViolationDetailRes getViolationDetail(Integer violationId);
}
