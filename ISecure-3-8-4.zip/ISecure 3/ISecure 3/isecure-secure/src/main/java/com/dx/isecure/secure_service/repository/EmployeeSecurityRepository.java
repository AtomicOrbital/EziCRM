package com.dx.isecure.secure_service.repository;

import com.dx.isecure.secure_service.entity.EmployeeSecurity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface EmployeeSecurityRepository extends JpaRepository<EmployeeSecurity, Integer> {

    @Query("FROM EmployeeSecurity WHERE employee.id = (:employeeId) AND period.id = (:periodId)")
    Optional<EmployeeSecurity> findByEmployeeIdAndPeriodId(Integer employeeId, Integer periodId);
}
