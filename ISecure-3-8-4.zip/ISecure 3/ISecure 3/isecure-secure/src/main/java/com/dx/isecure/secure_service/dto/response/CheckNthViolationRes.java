package com.dx.isecure.secure_service.dto.response;

import com.dx.isecure.secure_service.dto.EmployeeDto;
import com.dx.isecure.secure_service.dto.PeriodDto;
import com.dx.isecure.secure_service.dto.ViolationItemDto;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CheckNthViolationRes {
    private EmployeeDto employee;
    private ViolationItemDto violationItem;
    private PeriodDto period;
    private Integer nthViolation;
    private Integer minusPoint;
}
