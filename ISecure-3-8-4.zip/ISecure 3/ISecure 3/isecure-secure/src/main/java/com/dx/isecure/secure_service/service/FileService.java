package com.dx.isecure.secure_service.service;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

public interface FileService {

    ResponseEntity<Resource> downloadFile(String filename);

    String uploadFile(MultipartFile file);

    ResponseEntity<Resource> exportFile(String filename);
}
