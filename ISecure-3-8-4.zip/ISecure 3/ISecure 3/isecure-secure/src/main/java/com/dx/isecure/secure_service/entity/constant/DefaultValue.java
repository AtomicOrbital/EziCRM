package com.dx.isecure.secure_service.entity.constant;

public class DefaultValue {

    private DefaultValue() {
        throw new IllegalStateException("Utility class");
    }

    public static final Double SECURITY_POINT = 100D;
    public static final Integer TOTAL_VIOLATION = 0;
    public static final Integer MINUS_POINT = 0;
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm";
    public static final String DATE_FORMAT = "yyyy-MM-dd";
}
