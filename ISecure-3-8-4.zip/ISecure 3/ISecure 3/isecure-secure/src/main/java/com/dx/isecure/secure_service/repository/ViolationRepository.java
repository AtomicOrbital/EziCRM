package com.dx.isecure.secure_service.repository;

import com.dx.isecure.secure_service.dto.request.ViolationCriteria;
import com.dx.isecure.secure_service.dto.response.ViolationListProjection;
import com.dx.isecure.secure_service.entity.Violation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface ViolationRepository extends JpaRepository<Violation, Integer> {

    @EntityGraph(attributePaths = {
            "employeeSecurity.period",
            "employeeSecurity.employee",
            "violationItem.violationCategory"
    })
    @Query("FROM Violation WHERE id = (:violationId)")
    Optional<Violation> getDetailById(Integer violationId);

    @Query("SELECT COUNT(*) FROM Violation " +
            "WHERE employeeSecurity.id = (:employeeSecurityId) " +
            "AND violationItem.id = (:violationItemId)")
    Integer countViolationEmployeeByItem(Integer employeeSecurityId, Integer violationItemId);

    @Query(value = """
             SELECT
                 v.ID violationId,
                 vc.NAME violationCategory,
                 vi.NAME violationItem,
                 vi.SEVERITY severity,
                 e.NAME employee,
                 o.NAME organization,
                 v.NTH_VIOLATION nthViolation,
                 v.CREATED_AT violationTime,
                 v.CREATED_BY reporter,
                 v.MINUS_POINTS minusPoint
                        
             FROM VIOLATION v
                        
                 LEFT JOIN employee_security es
                 ON v.EMPLOYEE_SECURITY_ID = es.ID
                        
                 LEFT JOIN period p
                 ON p.ID = es.PERIOD_ID
                        
                 LEFT JOIN employee e
                 ON e.ID = es.EMPLOYEE_ID
                        
                 LEFT JOIN org_employee oe
                 ON e.ID = oe.EMPLOYEE_ID
                  AND ((oe.TIME_LEFT is null AND v.CREATED_AT >= oe.TIME_JOIN)
                    OR (v.CREATED_AT BETWEEN oe.TIME_JOIN AND oe.TIME_LEFT))
                        
                 LEFT JOIN organization o
                 ON o.ID = oe.ORG_ID
                        
                 LEFT JOIN violation_item vi
                 ON v.VIOLATION_ITEM_ID = vi.ID
                        
                 LEFT JOIN violation_category vc
                 ON vi.VIOLATION_CATEGORY_ID= vc.ID
                        
             WHERE 1 = 1
                AND p.ID = (:#{#req.periodId})
                AND (:#{#req.searchStartDate} IS NULL OR v.CREATED_AT >= :#{#req.searchStartDate})
                AND (:#{#req.searchEndDate} IS NULL OR v.CREATED_AT <= :#{#req.searchEndDate})
                AND (:#{#req.organizationId} IS NULL OR o.ID = :#{#req.organizationId})
                AND (:#{#req.violationCategoryId} IS NULL OR vc.ID = :#{#req.violationCategoryId})
                AND (:#{#req.violationItemId} IS NULL OR vi.ID = :#{#req.violationItemId})
                AND (:#{#req.itemSeverity} IS NULL OR vi.SEVERITY = :#{#req.itemSeverity != null ? #req.itemSeverity.getStr() : null})
                AND (:#{#req.employeeSearchKey} IS NULL 
                    OR e.EMPLOYEE_NO LIKE %:#{#req.employeeSearchKey}%
                    OR e.NAME LIKE %:#{#req.employeeSearchKey}%
                    OR e.EMAIL LIKE %:#{#req.employeeSearchKey}%
                    OR e.JOB_TITLE LIKE %:#{#req.employeeSearchKey}%
                    OR e.PHONE_NO LIKE %:#{#req.employeeSearchKey}%
                )
            """, nativeQuery = true)
    Page<ViolationListProjection> getViolationListInCurrentPeriod(ViolationCriteria req, Pageable pageable);

    @Query(value = """
             SELECT
                 v.ID violationId,
                 vc.NAME violationCategory,
                 vi.NAME violationItem,
                 vi.SEVERITY severity,
                 e.NAME employee,
                 o.NAME organization,
                 v.NTH_VIOLATION nthViolation,
                 v.CREATED_AT violationTime,
                 v.CREATED_BY reporter,
                 v.MINUS_POINTS minusPoint
                        
             FROM VIOLATION v
                        
                 LEFT JOIN employee_security es
                 ON v.EMPLOYEE_SECURITY_ID = es.ID
                        
                 LEFT JOIN period p
                 ON p.ID = es.PERIOD_ID
                        
                 LEFT JOIN employee e
                 ON e.ID = es.EMPLOYEE_ID
                        
                 LEFT JOIN org_employee oe
                 ON e.ID = oe.EMPLOYEE_ID
                  AND ((oe.TIME_LEFT is null AND v.CREATED_AT >= oe.TIME_JOIN)
                    OR (v.CREATED_AT BETWEEN oe.TIME_JOIN AND oe.TIME_LEFT))
                        
                 LEFT JOIN organization_backup o
                 ON o.ID = oe.ORG_ID
                        
                 LEFT JOIN violation_item_backup vi
                 ON v.VIOLATION_ITEM_ID = vi.ID
                        
                 LEFT JOIN violation_category_backup vc
                 ON vi.VIOLATION_CATEGORY_ID= vc.ID
                        
             WHERE 1 = 1
                AND p.ID = (:#{#req.periodId})
                AND (:#{#req.searchStartDate} IS NULL OR v.CREATED_AT >= :#{#req.searchStartDate})
                AND (:#{#req.searchEndDate} IS NULL OR v.CREATED_AT <= :#{#req.searchEndDate})
                AND (:#{#req.organizationId} IS NULL OR o.ID = :#{#req.organizationId})
                AND (:#{#req.violationCategoryId} IS NULL OR vc.ID = :#{#req.violationCategoryId})
                AND (:#{#req.violationItemId} IS NULL OR vi.ID = :#{#req.violationItemId})
                AND (:#{#req.itemSeverity} IS NULL OR vi.SEVERITY = :#{#req.itemSeverity != null ? #req.itemSeverity.getStr() : null})
                AND (:#{#req.employeeSearchKey} IS NULL 
                    OR e.EMPLOYEE_NO LIKE %:#{#req.employeeSearchKey}%
                    OR e.NAME LIKE %:#{#req.employeeSearchKey}%
                    OR e.EMAIL LIKE %:#{#req.employeeSearchKey}%
                    OR e.JOB_TITLE LIKE %:#{#req.employeeSearchKey}%
                    OR e.PHONE_NO LIKE %:#{#req.employeeSearchKey}%
                )
            """, nativeQuery = true)
    Page<ViolationListProjection> getViolationListForPastPeriod(ViolationCriteria req, Pageable pageable);
}
