package com.dx.isecure.secure_service.dto;

import com.dx.isecure.secure_service.dto.response.EmployeeRes;
import com.dx.isecure.secure_service.entity.constant.OrgState;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class OrganizationDto {
    Integer id;
    String orgCode;
    EmployeeRes orgPic;
    String name;
    OrgState state;
    LocalDate startDate;
    LocalDate endDate;
}
