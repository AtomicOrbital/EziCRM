package com.dx.isecure.secure_service.dto.request;

import com.dx.isecure.common.web.utils.constant.State;
import com.dx.isecure.common.web.utils.validator.annotation.DateRange;
import jakarta.validation.constraints.*;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@DateRange(startField = "enteringDate", endField = "leavingDate", message = "Leaving date must after entering date")
public class EmployeeReq {
    Integer id;
    
    @NotBlank(message = "Employee number must not be blank")
    String employeeNo;

    @NotBlank(message = "Name must not be blank")
    @Pattern(regexp = "^[a-zA-Z0-9\\s]*$", message = "Name must contain only Latin letters, numbers, and spaces (no accents allowed)")
    String name;

    @NotBlank(message = "Email must not be blank")
    @Email(message = "Email must be a valid email address")
    String email;

    @NotNull(message = "Entering date must not be null")
    LocalDate enteringDate;

    LocalDate leavingDate;

    @NotBlank(message = "Job title must not be blank")
    String jobTitle;

    @NotBlank(message = "Phone number must not be blank")
    String phoneNo;

    // TODO: pending for api auth service
    // Role role;
}
