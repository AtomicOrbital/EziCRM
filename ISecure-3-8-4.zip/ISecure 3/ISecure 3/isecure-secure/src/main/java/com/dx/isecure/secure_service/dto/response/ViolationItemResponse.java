package com.dx.isecure.secure_service.dto.response;

import lombok.Data;

@Data
public class ViolationItemResponse {
    private Integer id;
    private String code;
    private String name;
    private String severity;
    private String status;
    private String minusPointsRule;
    private String definition;
}
