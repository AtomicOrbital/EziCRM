package com.dx.isecure.secure_service.dto.request;

import com.dx.isecure.secure_service.entity.constant.Severity;
import lombok.Data;

import java.time.LocalDate;

@Data
public class ViolationCriteria {
    private Integer periodId;
    private LocalDate searchStartDate;
    private LocalDate searchEndDate;
    private Integer organizationId;
    private Integer violationCategoryId;
    private Integer violationItemId;
    private Severity itemSeverity;
    private String employeeSearchKey;
}
