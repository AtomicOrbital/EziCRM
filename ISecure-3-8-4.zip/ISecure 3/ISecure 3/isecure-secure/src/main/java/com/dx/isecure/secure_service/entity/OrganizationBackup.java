package com.dx.isecure.secure_service.entity;

import com.dx.isecure.secure_service.entity.constant.OrgState;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;

@Entity
@Table(name = "ORGANIZATION_BACKUP")
@Data
public class OrganizationBackup {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "ORG_CODE")
    private String orgCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ORG_PIC")
    private Employee orgPic;

    @Column(name = "NAME")
    private String name;

    @Column(name = "STATE")
    @Enumerated(EnumType.STRING)
    private OrgState state;

    @Column(name = "START_DATE")
    private LocalDate startDate;

    @Column(name = "END_DATE")
    private LocalDate endDate;

    @Column(name = "PERIOD_ID")
    private Integer periodId;
}
