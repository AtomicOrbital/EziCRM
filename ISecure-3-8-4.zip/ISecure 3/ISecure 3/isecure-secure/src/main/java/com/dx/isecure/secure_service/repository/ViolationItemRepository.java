package com.dx.isecure.secure_service.repository;

import com.dx.isecure.common.web.utils.constant.State;
import com.dx.isecure.secure_service.entity.ViolationItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ViolationItemRepository extends JpaRepository<ViolationItem, Integer> {
    Optional<ViolationItem> findByIdAndStatus(Integer itemId, State state);

    @Query("FROM ViolationItem WHERE violationCategory.id = (:categoryId)")
    List<ViolationItem> findAllByCategoryI(Integer categoryId);

    @Query(value = "SELECT *, " +
            "NULL CREATED_AT, " +
            "NULL CREATED_BY, " +
            "NULL UPDATED_AT, " +
            "NULL UPDATED_BY, " +
            "NULL DELETED_AT, " +
            "NULL DELETED_BY " +
            "FROM VIOLATION_ITEM_BACKUP " +
            "WHERE PERIOD_ID = (:#{#periodId}) " +
            "AND VIOLATION_CATEGORY_ID = (:#{#categoryId})", nativeQuery = true)
    List<ViolationItem> getItemInPastPeriodByCategory(Integer periodId, Integer categoryId);

    @Query(value = "SELECT *, " +
            "NULL CREATED_AT, " +
            "NULL CREATED_BY, " +
            "NULL UPDATED_AT, " +
            "NULL UPDATED_BY, " +
            "NULL DELETED_AT, " +
            "NULL DELETED_BY " +
            "FROM VIOLATION_ITEM_BACKUP " +
            "WHERE ID = (:#{#itemId}) " +
            "AND PERIOD_ID = (:#{#periodId})", nativeQuery = true)
    Optional<ViolationItem> getItemInPastPeriodById(Integer itemId, Integer periodId);

    @Query("SELECT i " +
            "FROM ViolationItem " +
            "i WHERE i.deletedAt IS NULL " +
            "AND i.violationCategory.id = :categoryId")
    List<ViolationItem> findByViolationCategoryId(@Param("categoryId") Integer categoryId);

    @Query(
            value = "SELECT COUNT(*) FROM VIOLATION_ITEM i WHERE i.VIOLATION_CATEGORY_ID IN (SELECT id FROM VIOLATION_CATEGORY WHERE LOWER(NAME) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(CODE) LIKE LOWER(CONCAT('%', :keyword, '%')))",
            nativeQuery = true)
    int countItemsByKeyword(@Param("keyword") String keyword);

    Optional<ViolationItem> findByCodeOrName(String code, String name);


    Optional<ViolationItem> findByCode(String itemCode);
}
