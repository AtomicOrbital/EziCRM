package com.dx.isecure.secure_service.dto.response;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class ViolationCategoryResponse {
    private int id;
    private String code;
    private String name;
}
