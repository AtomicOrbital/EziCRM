package com.dx.isecure.secure_service.service;

import com.dx.isecure.common.web.request.PagingReq;
import com.dx.isecure.secure_service.dto.request.DeleteEmployeeReq;
import com.dx.isecure.secure_service.dto.request.OrgEmployeesReq;
import com.dx.isecure.secure_service.dto.response.EmployeeRes;
import org.springframework.data.domain.Page;

public interface OrgEmployeeService {
    void addEmployeesToOrganization(Integer orgId, OrgEmployeesReq orgEmployeesReq);

    void removeEmployeesFromOrg(DeleteEmployeeReq deleteEmployeeReq);

    Page<EmployeeRes> getEmployeesOfOrg(Integer orgId, String keySearch, PagingReq pagingReq);
}
