package com.dx.isecure.secure_service.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class PeriodDto {
    private Integer id;
    private LocalDate periodStartDate;
    private LocalDate periodEndDate;
    private Boolean isCurrentPeriod;
}
