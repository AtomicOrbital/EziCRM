package com.dx.isecure.secure_service.entity;

import com.dx.isecure.common.utils.auditaware.AuditEntity;
import com.dx.isecure.common.web.utils.constant.State;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "EMPLOYEE")
@Data
public class Employee extends AuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "EMPLOYEE_NO")
    private String employeeNo;

    @Column(name = "NAME")
    private String name;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "JOB_TITLE")
    private String jobTitle;

    @Column(name = "PHONE_NO")
    private String phoneNo;

    @Column(name = "ENTERING_DATE")
    private LocalDate enteringDate;

    @Column(name = "LEAVING_DATE")
    private LocalDate leavingDate;

    @Column(name = "STATE")
    @Enumerated(EnumType.STRING)
    private State state;

    @Column(name = "ACCOUNT_ID")
    private Integer accountId;
}