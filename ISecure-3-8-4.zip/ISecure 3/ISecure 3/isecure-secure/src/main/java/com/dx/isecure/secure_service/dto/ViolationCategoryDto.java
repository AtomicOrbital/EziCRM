package com.dx.isecure.secure_service.dto;

import com.dx.isecure.common.web.utils.constant.State;
import lombok.Data;

@Data
public class ViolationCategoryDto {
    private Integer id;
    private String code;
    private String name;
    private State status;
}
