package com.dx.isecure.secure_service.service;

import com.dx.isecure.common.web.request.PagingReq;
import com.dx.isecure.common.web.utils.constant.State;
import com.dx.isecure.secure_service.dto.request.EmployeeReq;
import com.dx.isecure.secure_service.dto.response.EmployeeRes;
import org.springframework.data.domain.Page;
import com.dx.isecure.secure_service.dto.request.DeleteEmployeeReq;

public interface EmployeeService {
    Page<EmployeeRes> getEmployees(String keySearch, State state,  PagingReq pagingReq);
    EmployeeRes upsertEmployee(EmployeeReq employeeReq);
    void deleteEmployees(DeleteEmployeeReq deleteEmployeeReq);
}
