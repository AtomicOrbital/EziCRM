package com.dx.isecure.secure_service.dto.response;

import com.dx.isecure.secure_service.entity.constant.DefaultValue;
import com.dx.isecure.secure_service.entity.constant.Severity;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ViolationListRes {
    private Integer violationId;
    private String violationCategory;
    private String violationItem;
    private Severity severity;
    private String employee;
    private String organization;
    private Integer nthViolation;
    private String reporter;
    private Integer minusPoint;

    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonFormat(pattern = DefaultValue.DATE_TIME_FORMAT)
    private LocalDateTime violationTime;
}
