package com.dx.isecure.secure_service.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;
import java.util.UUID;

@Data
public class RegisterViolationReq {
    @NotNull(message = "employeeId must not be null")
    private Integer employeeId;
    @NotNull(message = "violationItemId must not be null")
    private Integer violationItemId;
    private String description;
    private List<UUID> evidences;
}
