package com.dx.isecure.common.utils.token;

import com.dx.isecure.common.web.exception.common.BusinessException;
import com.dx.isecure.common.web.exception.common.ServiceError;
import com.google.common.base.Strings;
import com.google.common.net.HttpHeaders;
import io.jsonwebtoken.*;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Map;

@Component
@Slf4j
public class TokenUtils {

    public String getTokenFromRequest(HttpServletRequest req) {
        String authHeader = req.getHeader(HttpHeaders.AUTHORIZATION);

        if (Strings.nullToEmpty(authHeader).trim().isEmpty()) {
            return null;
        }

        String[] parts = authHeader.split(" ");
        if (parts.length != 2 || !DefaultValue.TOKEN_TYPE.equals(parts[0])) {
            return null;
        }

        return parts[1];
    }

    public String generateJwtToken(String subject, Map<String, Object> claims, Long jwtExpirationMs, String secretKey) {
        return Jwts.builder()
                .setSubject(subject)
                .addClaims(claims)
                .setIssuedAt(new Date())
                .setExpiration(new Date((new Date()).getTime() + jwtExpirationMs))
                .signWith(SignatureAlgorithm.HS512, secretKey)
                .compact();
    }

    public String getSubjectFromJwtToken(String token, String secretKey) {
        return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody().getSubject();
    }

    public Claims validateJwtToken(String authToken, String secretKey) {
        try {
            return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(authToken).getBody();
        } catch (SignatureException e) {
            log.error("Invalid JWT signature: {}", e.getMessage());
            throw new BusinessException(ServiceError.INVALID_TOKEN);
        } catch (MalformedJwtException e) {
            log.error("Invalid JWT token: {}", e.getMessage());
            throw new BusinessException(ServiceError.INVALID_TOKEN);
        } catch (ExpiredJwtException e) {
            log.error("JWT token is expired: {}", e.getMessage());
            throw new BusinessException(ServiceError.TOKEN_EXPIRED);
        } catch (UnsupportedJwtException e) {
            log.error("JWT token is unsupported: {}", e.getMessage());
            throw new BusinessException(ServiceError.INVALID_TOKEN_FORMAT);
        } catch (IllegalArgumentException e) {
            log.error("JWT claims string is empty: {}", e.getMessage());
            throw new BusinessException(ServiceError.TOKEN_INFO_INCORRECT);
        }
    }

}
