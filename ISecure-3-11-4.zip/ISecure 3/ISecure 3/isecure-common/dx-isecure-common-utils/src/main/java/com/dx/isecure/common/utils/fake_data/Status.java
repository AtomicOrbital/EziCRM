package com.dx.isecure.common.utils.fake_data;

public enum Status {
    ACTIVE,
    INACTIVE
}
