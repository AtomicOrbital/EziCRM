package com.dx.isecure.common.utils.token;

public class DefaultValue {

    private DefaultValue() {
        throw new IllegalStateException("Utility class");
    }

    public static final String TOKEN_TYPE = "Bearer";
}
