package com.dx.isecure.common.web.exception.common;

import com.google.common.collect.Maps;

import java.util.Collections;
import java.util.LinkedHashMap;

public class BusinessException extends ServiceException {

    public BusinessException(ServiceError err, Throwable ex, LinkedHashMap<String, Object> params) {
        super(err, ex, params);
    }

    public BusinessException(ServiceError err) {
        super(err, null, null);
    }

    public BusinessException(ServiceError err, LinkedHashMap<String, Object> params) {
        super(err, null, params);
    }

    protected static LinkedHashMap<String, Object> buildSingleParamMaps(String key, String value) {
        return Maps.newLinkedHashMap(Collections.singletonMap(key, value));
    }
}
