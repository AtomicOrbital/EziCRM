package com.dx.isecure.common.web.exception.common;

import java.util.LinkedHashMap;

public class SysException extends ServiceException {

    private final String printMessage;

    protected SysException(ServiceError err, Throwable ex, LinkedHashMap<String, Object> params) {
        super(err, ex, params);
        printMessage = "";
    }

    public SysException(String printMessage, Throwable ex) {
        super(ServiceError.UNEXPECTED_EXCEPTION, ex, null);
        this.printMessage = printMessage;
    }

    public SysException(String printMessage) {
        this(printMessage, null);
    }

    public String getPrintMessage() {
        return printMessage;
    }
}