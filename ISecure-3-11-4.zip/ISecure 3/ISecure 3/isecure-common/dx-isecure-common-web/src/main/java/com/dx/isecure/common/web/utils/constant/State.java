package com.dx.isecure.common.web.utils.constant;

import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

@Getter
public enum State {
    ACTIVE(1, "ACTIVE"),
    IN_ACTIVE(2, "IN_ACTIVE");

    State(int code, String str) {
        this.code = code;
        this.str = str;
    }

    private static final Map<String, State> ACCOUNT_STATE_MAP = new HashMap<>();

    static {
        for (State e : values()) {
            ACCOUNT_STATE_MAP.put(e.getStr(), e);
        }
    }

    private final int code;
    private final String str;

    public static State getByStr(String str) {
        return ACCOUNT_STATE_MAP.get(str);
    }
}
