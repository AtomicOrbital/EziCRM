package com.dx.isecure.common.web.response;

import com.dx.isecure.common.web.exception.common.ServiceError;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;

import java.util.Map;

@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ErrorResponse extends Response {

    private final String errKey;
    private final Map<String, Object> params;

    protected ErrorResponse(ServiceError serviceError, String message, Map<String, Object> params) {
        this.result = false;
        this.code = serviceError.getErrCode();
        this.errKey = serviceError.getMessageKey();
        this.message = message;
        this.params = params;
    }

    public static ErrorResponse of(ServiceError serviceError) {
        return new ErrorResponse(serviceError, null, null);
    }

    public static ErrorResponse of(ServiceError serviceError, String details) {
        return new ErrorResponse(serviceError, details, null);
    }

    public static ErrorResponse of(ServiceError serviceError, String details, Map<String, Object> params) {
        return new ErrorResponse(serviceError, details, params);
    }
}