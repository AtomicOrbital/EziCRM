package com.dx.isecure.common.web.response;

import lombok.Getter;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Getter
public enum ServiceMessage {
    RESPONSE_OK(200000, "response.success.ok"),
    CREATE_DATA_SUCCESS(200001, "response.data.create.success");

    ServiceMessage(int code, String messageKey) {
        this.code = code;
        this.messageKey = messageKey;
    }

    private static final Map<String, ServiceMessage> RESPONSE_MAP = new HashMap<>();

    static {
        for (ServiceMessage e : values()) {
            RESPONSE_MAP.put(e.getMessageKey(), e);
        }
    }

    private final int code;
    private final String messageKey;

    public static ServiceMessage getByMessageKey(String messageKey) {
        return Optional.ofNullable(RESPONSE_MAP.get(messageKey))
                .orElse(RESPONSE_OK);
    }

}
