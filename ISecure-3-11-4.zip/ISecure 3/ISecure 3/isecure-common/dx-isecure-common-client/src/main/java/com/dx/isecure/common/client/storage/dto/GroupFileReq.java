package com.dx.isecure.common.client.storage.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class GroupFileReq {
    private String fileGroupId;
    private List<String> fileIds;
}
