package com.dx.isecure.common.client.storage;

import com.dx.isecure.common.client.storage.dto.AttachmentDto;
import com.dx.isecure.common.client.storage.dto.GroupFileReq;

import java.util.List;

public interface IStorageClient {
    Object groupFiles(GroupFileReq req);

    List<AttachmentDto> getFilesByGroupId(String groupId);
}
