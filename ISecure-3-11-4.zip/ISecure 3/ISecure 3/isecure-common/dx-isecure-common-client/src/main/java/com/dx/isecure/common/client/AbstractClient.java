package com.dx.isecure.common.client;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.Collections;
import java.util.Optional;
import java.util.UUID;

public abstract class AbstractClient {
    protected RestTemplate restTemplate;

    public static final String TOKEN_TYPE_BEARER = "Bearer";
    private static final String FULL_TOKEN_FORMAT = "%s %s";

    protected AbstractClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    protected HttpHeaders createAuthHeaders() {
        // TODO: Passing auth token into header
        HttpHeaders httpHeaders = createDefaultHeaders();
        String bearerToken = getBearerToken(UUID.randomUUID().toString());
        httpHeaders.put(HttpHeaders.AUTHORIZATION, Collections.singletonList(bearerToken));
        return httpHeaders;
    }

    protected HttpHeaders createDefaultHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }

    protected <T> T getForObject(URI uri, HttpHeaders headers, Class<T> clazz) {
        HttpEntity<Object> request = new HttpEntity<>(headers);
        return restTemplate.exchange(uri, HttpMethod.GET, request, clazz).getBody();
    }

    private String getBearerToken(String token) {
        return String.format(FULL_TOKEN_FORMAT,
                Optional.of(TOKEN_TYPE_BEARER).orElse(""),
                Optional.ofNullable(token).orElse(""));
    }

}
