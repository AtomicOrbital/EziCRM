package com.dx.isecure.common.redis;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.listener.PatternTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;

import java.lang.reflect.Method;


@Configuration
public class RedisQueueListenerRegistrar implements CommandLineRunner {

    private final ApplicationContext applicationContext;
    private final RedisConnectionFactory redisConnectionFactory;

    @Autowired
    public RedisQueueListenerRegistrar(ApplicationContext applicationContext, RedisConnectionFactory redisConnectionFactory) {
        this.applicationContext = applicationContext;
        this.redisConnectionFactory = redisConnectionFactory;
    }

    @Override
    public void run(String... args) throws Exception {
        RedisMessageListenerContainer container = new RedisMessageListenerContainer();
        container.setConnectionFactory(redisConnectionFactory);

        // Scan for beans with @RedisQueueListener methods
        String[] beanNames = applicationContext.getBeanDefinitionNames();
        for (String beanName : beanNames) {
            try {
                Object bean = applicationContext.getBean(beanName);
                for (Method method : bean.getClass().getDeclaredMethods()) {
                    if (method.isAnnotationPresent(RedisQueueListener.class)) {
                        RedisQueueListener annotation = method.getAnnotation(RedisQueueListener.class);
                        String channel = annotation.channel();
                        if (!channel.isEmpty()) {
                            RedisMessageListener listener = new RedisMessageListener(
                                    bean,
                                    method,
                                    throwable -> throwable.printStackTrace()
                            );
                            container.addMessageListener(listener, new PatternTopic(channel));
                        }
                    }
                }
            } catch (Exception e) {
                // Log and skip beans that can't be instantiated
                System.err.println("Failed to process bean: " + beanName + " - " + e.getMessage());
            }
        }

        container.afterPropertiesSet();
        container.start();
    }
}