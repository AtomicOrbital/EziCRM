package com.dx.isecure.common.redis;

import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import java.lang.reflect.Method;
import java.util.function.Consumer;

public class RedisMessageListener implements MessageListener {
    private final Object bean;
    private final Method method;
    private final Consumer<Throwable> errorHandler;

    public RedisMessageListener(Object bean, Method method, Consumer<Throwable> errorHandler) {
        this.bean = bean;
        this.method = method;
        this.errorHandler = errorHandler;
    }

    @Override
    public void onMessage(Message message, byte[] pattern) {
        try {
            // Deserialize the message body (assuming String for simplicity)
            String body = new String(message.getBody());
            // Invoke the annotated method
            method.invoke(bean, body);
        } catch (Exception e) {
            errorHandler.accept(e);
        }
    }
}