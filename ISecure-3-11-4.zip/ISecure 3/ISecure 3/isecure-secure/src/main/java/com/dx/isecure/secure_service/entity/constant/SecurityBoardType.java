package com.dx.isecure.secure_service.entity.constant;

import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

@Getter
public enum SecurityBoardType {
    CASE(1, "CASE"),
    REPORT(2, "REPORT");

    SecurityBoardType(int code, String str) {
        this.code = code;
        this.str = str;
    }

    private static final Map<String, SecurityBoardType> SECURITY_BARD_TYPE_MAP = new HashMap<>();

    static {
        for (SecurityBoardType e : values()) {
            SECURITY_BARD_TYPE_MAP.put(e.getStr(), e);
        }
    }

    private final int code;
    private final String str;

    public static SecurityBoardType getByStr(String str) {
        return SECURITY_BARD_TYPE_MAP.get(str);
    }
}
