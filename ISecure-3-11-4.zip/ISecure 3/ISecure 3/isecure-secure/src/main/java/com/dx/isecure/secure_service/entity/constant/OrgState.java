package com.dx.isecure.secure_service.entity.constant;

import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

@Getter
public enum OrgState {
    ACTIVE(1, "ACTIVE"),
    IN_ACTIVE(2, "IN_ACTIVE");

    OrgState(int code, String str) {
        this.code = code;
        this.str = str;
    }

    private static final Map<String, OrgState> ORG_STATE_MAP = new HashMap<>();

    static {
        for (OrgState e : values()) {
            ORG_STATE_MAP.put(e.getStr(), e);
        }
    }

    private final int code;
    private final String str;

    public static OrgState getByStr(String str) {
        return ORG_STATE_MAP.get(str);
    }
}
