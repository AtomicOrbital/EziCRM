package com.dx.isecure.secure_service.controller;

import com.dx.isecure.common.web.request.PagingReq;
import com.dx.isecure.common.web.response.Response;
import com.dx.isecure.common.web.response.ResponseUtils;
import com.dx.isecure.secure_service.dto.request.CheckNthViolationReq;
import com.dx.isecure.secure_service.dto.request.RegisterViolationReq;
import com.dx.isecure.secure_service.dto.request.ViolationCriteria;
import com.dx.isecure.secure_service.service.ViolationService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
@RequestMapping("/violations")
@CrossOrigin("*")
public class ViolationController {
    private final ViolationService violationService;

    @Operation(summary = "Check num of times employee has been violated with a specific item")
    @PostMapping("/check-nth-same-violation")
    public ResponseEntity<Response> checkNthSameViolation(@RequestBody @Valid CheckNthViolationReq checkNthViolationReq) {
        return ResponseUtils.ok(violationService.checkNthSameViolation(checkNthViolationReq));
    }

    @Operation(summary = "Register a new violation of employee")
    @PostMapping("/register-violation")
    public ResponseEntity<Response> registerViolation(@RequestBody @Valid RegisterViolationReq registerViolationReq) {
        return ResponseUtils.ok(violationService.registerViolation(registerViolationReq));
    }

    @Operation(summary = "Get violation list in period")
    @PostMapping("")
    public ResponseEntity<Response> getViolationList(@RequestBody ViolationCriteria violationCriteria, @ParameterObject PagingReq pagingReq) {
        return ResponseUtils.ok(violationService.getViolationList(violationCriteria, pagingReq));
    }

    @Operation(summary = "Get violation detail")
    @GetMapping("/{violationId}")
    public ResponseEntity<Response> getViolationDetail(@PathVariable("violationId") Integer violationId) {
        return ResponseUtils.ok(violationService.getViolationDetail(violationId));
    }
}
