package com.dx.isecure.secure_service.service.impl;

import com.dx.isecure.common.web.utils.MappingHelper;
import com.dx.isecure.secure_service.dto.PeriodDto;
import com.dx.isecure.secure_service.repository.PeriodRepository;
import com.dx.isecure.secure_service.service.PeriodService;
import com.dx.isecure.secure_service.util.BusinessUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class PeriodServiceImpl implements PeriodService {
    private final PeriodRepository periodRepository;
    private final MappingHelper mappingHelper;

    @Override
    public List<PeriodDto> getPeriodList() {
        return periodRepository.findAll()
                .stream().map(e -> {
                    var periodDto = mappingHelper.map(e, PeriodDto.class);
                    periodDto.setIsCurrentPeriod(BusinessUtil.isCurrentPeriod(e));
                    return periodDto;
                }).toList();
    }
}
