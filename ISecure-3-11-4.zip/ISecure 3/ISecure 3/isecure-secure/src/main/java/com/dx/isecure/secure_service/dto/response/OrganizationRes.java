package com.dx.isecure.secure_service.dto.response;

import com.dx.isecure.secure_service.dto.EmployeeDto;
import com.dx.isecure.secure_service.entity.constant.OrgState;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class OrganizationRes {
    Integer id;
    String orgCode;
    String name;
    OrgState state;
    LocalDate startDate;
    LocalDate endDate;
    EmployeeDto orgPic;
    List<OrganizationRes> children;
}
