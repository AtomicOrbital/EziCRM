package com.dx.isecure.secure_service.service;

import com.dx.isecure.common.web.request.PagingReq;
import com.dx.isecure.common.web.utils.constant.State;
import com.dx.isecure.secure_service.dto.request.EmployeeReq;
import com.dx.isecure.secure_service.dto.response.EmployeeDetailRes;
import com.dx.isecure.secure_service.dto.response.EmployeeRes;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import com.dx.isecure.secure_service.dto.request.DeleteEmployeeReq;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

public interface EmployeeService {
    Page<EmployeeRes> getEmployees(String keySearch, State state,  PagingReq pagingReq);
    EmployeeRes upsertEmployee(EmployeeReq employeeReq);
    void deleteEmployees(DeleteEmployeeReq deleteEmployeeReq);
    EmployeeDetailRes getEmployeeDetail(Integer employeeId, boolean isCode);
    ResponseEntity<Resource> exportFile(String employeeFilename, String keySearch);
    List<Map<String, Object>> getMembersBase64(List<Integer> employeeIds);
}
