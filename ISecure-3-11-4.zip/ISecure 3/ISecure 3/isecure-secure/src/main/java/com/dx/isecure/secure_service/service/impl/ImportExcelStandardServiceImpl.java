package com.dx.isecure.secure_service.service.impl;

import com.dx.isecure.common.web.exception.common.BusinessException;
import com.dx.isecure.common.web.exception.common.ServiceError;
import com.dx.isecure.common.web.utils.MappingHelper;
import com.dx.isecure.common.web.utils.constant.State;
import com.dx.isecure.secure_service.dto.request.SecurityStandardRequest;
import com.dx.isecure.secure_service.entity.ViolationCategory;
import com.dx.isecure.secure_service.entity.ViolationItem;
import com.dx.isecure.secure_service.entity.constant.SecurityStandardType;
import com.dx.isecure.secure_service.entity.constant.Severity;
import com.dx.isecure.secure_service.repository.ViolationCategoryRepository;
import com.dx.isecure.secure_service.repository.ViolationItemRepository;
import com.dx.isecure.secure_service.service.ImportExcelStandardService;
import jakarta.servlet.http.HttpServletResponse;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ImportExcelStandardServiceImpl implements ImportExcelStandardService {
    ViolationCategoryRepository violationCategoryRepository;
    ViolationItemRepository violationItemRepository;
    MappingHelper mappingHelper;

    @Transactional
    public void importExcel(MultipartFile file, HttpServletResponse response) {
        boolean hasError = false;
        List<SecurityStandardRequest> validCategoryRequests = new ArrayList<>();
        List<SecurityStandardRequest> validItemRequests = new ArrayList<>();
        List<String> validItemMarks = new ArrayList<>();
        Map<Row, String> rowErrors = new LinkedHashMap<>();
        Set<String> existingCategoryCodes = new HashSet<>(violationCategoryRepository.findAllCodes());
        Set<String> existingCategoryNames = new HashSet<>(violationCategoryRepository.findAllNames());
        Set<String> existingItemCodes = new HashSet<>(violationItemRepository.findAllCodes());
        Set<String> existingItemNames = new HashSet<>(violationItemRepository.findAllNames());

        Set<String> inputCategoryCodes = new HashSet<>();
        Set<String> inputCategoryNames = new HashSet<>();
        Set<String> inputItemCodes = new HashSet<>();
        Set<String> inputItemNames = new HashSet<>();


        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);
            List<Row> dataRows = new ArrayList<>();
            for (Row row : sheet) {
                // Skip the header row
                if (row.getRowNum() < 2) {
                    continue;
                }
                dataRows.add(row);
            }

            for (Row row : dataRows) {
                // Read data from each cell column
                String code = getCellValueAsString(row.getCell(0));
                String categoryName = getCellValueAsString(row.getCell(1));
                String itemName = getCellValueAsString(row.getCell(2));
                String mark = getCellValueAsString(row.getCell(3));
                String severity = getCellValueAsString(row.getCell(4));

                if (!StringUtils.isBlank(itemName)) {
                    String inputSeverity = getCellValueAsString(row.getCell(4));
                    try {
                        severity = convertToSeverity(inputSeverity);
                    } catch (BusinessException be) {
                        severity = null;
                    }
                }

                String firstStr = getCellValueAsString(row.getCell(5));
                String secondStr = getCellValueAsString(row.getCell(6));
                String thirdStr = getCellValueAsString(row.getCell(7));
                String fourthStr = getCellValueAsString(row.getCell(8));
                String fifthStr = getCellValueAsString(row.getCell(9));
                String status = getCellValueAsString(row.getCell(10));
                try {
                    status = convertToStatus(status);
                } catch (BusinessException be) {
                    status = null;
                }

                // validate data row
                StringBuilder errorBuilder = new StringBuilder();


                if (StringUtils.isBlank(code)) {
                    errorBuilder.append("Code is required. ");
                }
                if (StringUtils.isBlank(categoryName) && StringUtils.isBlank(itemName)) {
                    errorBuilder.append("Category name is required. ");
                }

                // If the next cell has data but the previous cell does not
                if (!StringUtils.isBlank(secondStr) && StringUtils.isBlank(firstStr)) {
                    errorBuilder.append("2nd minus point cannot be entered if 1st is blank");
                }
                if (!StringUtils.isBlank(thirdStr) && StringUtils.isBlank(secondStr)) {
                    errorBuilder.append("3rd minus point cannot be entered if 2nd is blank");
                }
                if (!StringUtils.isBlank(fourthStr) && StringUtils.isBlank(thirdStr)) {
                    errorBuilder.append("4th minus point cannot be entered if 3rd is blank");
                }
                if (!StringUtils.isBlank(fifthStr) && StringUtils.isBlank(fourthStr)) {
                    errorBuilder.append("5th minus point cannot be entered if 4th is blank");
                }

                StringBuilder minusPointErrorBuilder = new StringBuilder();
                int firstPoint = validateAndParseMinusPoint(firstStr, "1st minus point", minusPointErrorBuilder);
                int secondPoint = validateAndParseMinusPoint(secondStr, "2nd minus point", minusPointErrorBuilder);
                int thirdPoint = validateAndParseMinusPoint(thirdStr, "3rd minus point", minusPointErrorBuilder);
                int fourthPoint = validateAndParseMinusPoint(fourthStr, "4th minus point", minusPointErrorBuilder);
                int fifthPoint = validateAndParseMinusPoint(fifthStr, "5th minus point", minusPointErrorBuilder);

                if (!minusPointErrorBuilder.isEmpty()) {
                    errorBuilder.append(minusPointErrorBuilder.toString());
                }

                // create list minusPoint
                List<Integer> minusPoints = Arrays.asList(firstPoint, secondPoint, thirdPoint, fourthPoint, fifthPoint);
                if (minusPoints == null || minusPoints.size() != 5) {
                    minusPoints = Arrays.asList(0, 0, 0, 0, 0);
                }

                int totalMinusPoint = minusPoints.stream().mapToInt(Integer::intValue).sum();
                // If have Item, have to Mark
                if (!StringUtils.isBlank(itemName)) {
                    if (StringUtils.isBlank(mark)) {
                        errorBuilder.append("For Item, Mark Category code is required. ");
                    }
                    if (severity == null) {
                        errorBuilder.append("Severity must be either HIGH or LOW or MEDIUM. ");
                    }
                    if (totalMinusPoint > 100) {
                        errorBuilder.append("Total minus points must be less than or equal to 100. ");
                    }

                }

                // check duplicate code in file
                if (StringUtils.isBlank(itemName)) {
                    if (inputCategoryCodes.contains(code)) {
                        errorBuilder.append("Duplicate Category code in input file. ");
                    } else {
                        inputCategoryCodes.add(code);
                    }
                    if (inputCategoryNames.contains(categoryName)) {
                        errorBuilder.append("Duplicate Category name in input file. ");
                    } else {
                        inputCategoryNames.add(categoryName);
                    }
                    if (existingCategoryCodes.contains(code)) {
                        errorBuilder.append("Duplicate Category code exists in DB. ");
                    }
                    if (existingCategoryNames.contains(categoryName)) {
                        errorBuilder.append("Duplicate Category name exists in DB. ");
                    }
                } else {
                    if (inputItemCodes.contains(code)) {
                        errorBuilder.append("Duplicate Item code in input file. ");
                    } else {
                        inputItemCodes.add(code);
                    }
                    if (inputItemNames.contains(itemName)) {
                        errorBuilder.append("Duplicate Item name in input file. ");
                    } else {
                        inputItemNames.add(itemName);
                    }
                    if (existingItemCodes.contains(code)) {
                        errorBuilder.append("Duplicate Item code exists in DB. ");
                    }
                    if (existingItemNames.contains(itemName)) {
                        errorBuilder.append("Duplicate Item name exists in DB. ");
                    }
                }

                // if have error, save error message rowErrors
                if (!errorBuilder.isEmpty()) {
                    rowErrors.put(row, errorBuilder.toString());
                    hasError = true;
                } else {
                    if (StringUtils.isBlank(mark)) {
                        // If mark is blank, create a new Category
                        if (violationCategoryRepository.findByCode(code).isPresent()) {
                            errorBuilder.append("Category code already exists.");
                        } else {
                            // Create new Category
                            SecurityStandardRequest req = new SecurityStandardRequest();
                            req.setType(SecurityStandardType.CATEGORY.name());
                            req.setCode(code);
                            req.setName(categoryName);
                            req.setStatus(status);
                            validCategoryRequests.add(req);
                        }
                    } else {
                        // Create new Item and associate with Category
                        SecurityStandardRequest itemReq = new SecurityStandardRequest();
                        itemReq.setType(SecurityStandardType.ITEM.name());
                        itemReq.setCode(code);
                        itemReq.setName(itemName);
                        itemReq.setStatus(status);
                        itemReq.setSeverity(severity);
                        itemReq.setMinusPoints(minusPoints);
                        validItemRequests.add(itemReq);
                        validItemMarks.add(mark);
                    }
                }
            }
            // If there is an error in any line, write the error to an Excel file and return the file to the user
            if (hasError) {
                for (Map.Entry<Row, String> entry : rowErrors.entrySet()) {
                    Row errorRow = entry.getKey();
                    String errorMessage = entry.getValue();
                    Cell errorCell = errorRow.createCell(11, CellType.STRING);
                    errorCell.setCellValue(errorMessage);
                }
                response.setHeader("Content-Disposition", "attachment; filename=import_with_errors.xlsx");
                workbook.write(response.getOutputStream());
                response.getOutputStream().flush();
                return;
            }
            // if no error, save validCategoryRequests and validItemRequests to database
            if (!validCategoryRequests.isEmpty()) {
                List<ViolationCategory> categoryList = mappingHelper.mapList(validCategoryRequests, ViolationCategory.class);
                violationCategoryRepository.saveAll(categoryList);
            }

            if (!validItemRequests.isEmpty()) {
                for (int i = 0; i < validItemRequests.size(); i++) {
                    SecurityStandardRequest req = validItemRequests.get(i);
                    String markValue = validItemMarks.get(i);
                    ViolationCategory category = violationCategoryRepository.findByCode(markValue)
                            .orElseThrow(() -> new BusinessException(ServiceError.REQUIRED_CODE_AND_NAME, null,
                                    createParamMap("Mark", "Category with code " + markValue + " not found.")));
                    req.setViolationCategoryId(category.getId());
                }
                List<ViolationItem> itemEntities = new ArrayList<>();
                for (SecurityStandardRequest req : validItemRequests) {
                    ViolationItem item = new ViolationItem();
                    item.setCode(req.getCode());
                    item.setName(req.getName());
                    item.setStatus(State.valueOf(req.getStatus()));
                    item.setSeverity(Severity.valueOf(req.getSeverity()));
                    String minusPointsStr = req.getMinusPoints().stream()
                            .map(String::valueOf)
                            .collect(Collectors.joining("/"));
                    item.setMinusPointsRule(minusPointsStr);
                    ViolationCategory cat = violationCategoryRepository.findById(req.getViolationCategoryId())
                            .orElseThrow(() -> new BusinessException(ServiceError.REQUIRED_CODE_AND_NAME, null,
                                    createParamMap("CategoryId", "Category not found for id " + req.getViolationCategoryId())));
                    item.setViolationCategory(cat);
                    itemEntities.add(item);
                }
                violationItemRepository.saveAll(itemEntities);
            }
        } catch (Exception e) {
            throw new BusinessException(ServiceError.FILE_PROCESSING_ERROR, e, null);
        }
    }

    private String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return "";
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getLocalDateTimeCellValue().toLocalDate().toString();
                } else {
                    double numericValue = cell.getNumericCellValue();
                    if (numericValue == (long) numericValue) {
                        return String.valueOf((long) numericValue);
                    } else {
                        return String.valueOf(numericValue);
                    }
                }
            case BOOLEAN:
                return Boolean.toString(cell.getBooleanCellValue());
            case FORMULA:
                switch (cell.getCachedFormulaResultType()) {
                    case NUMERIC:
                        if (DateUtil.isCellDateFormatted(cell)) {
                            return cell.getLocalDateTimeCellValue().toLocalDate().toString();
                        } else {
                            double numericValue = cell.getNumericCellValue();
                            if (numericValue == (long) numericValue) {
                                return String.valueOf((long) numericValue);
                            } else {
                                return String.valueOf(numericValue);
                            }
                        }
                    case STRING:
                        return cell.getStringCellValue();
                    case BOOLEAN:
                        return Boolean.toString(cell.getBooleanCellValue());
                    default:
                        return "";
                }
            case BLANK:
            default:
                return "";
        }
    }

    private String convertToSeverity(String input) {
        if (StringUtils.isBlank(input)) {
            LinkedHashMap<String, Object> params = new LinkedHashMap();
            params.put("Severity", "Severity is required");
            throw new BusinessException(ServiceError.INVALID_INPUT, null, params);
        }
        String normalized = input.trim().toUpperCase();
        if (Severity.HIGH.name().equals(normalized) || Severity.LOW.name().equals(normalized) || Severity.MEDIUM.name().equals(normalized)) {
            return normalized;
        } else {
            LinkedHashMap<String, Object> params = new LinkedHashMap();
            params.put("Severity", "Severity must be either HIGH or LOW or MEDIUM");
            throw new BusinessException(ServiceError.INVALID_INPUT, null, params);
        }
    }

    private String convertToStatus(String input) {
        if (StringUtils.isBlank(input)) {
            LinkedHashMap<String, Object> params = new LinkedHashMap();
            params.put("Status", "Status is required");
            throw new BusinessException(ServiceError.INVALID_INPUT, null, params);
        }
        String normalized = input.trim().toUpperCase();
        if ("ACTIVE".equals(normalized)) {
            return State.ACTIVE.name();
        } else if ("INACTIVE".equals(normalized) || "IN_ACTIVE".equals(normalized)) {
            return State.IN_ACTIVE.name();
        } else {
            LinkedHashMap<String, Object> params = new LinkedHashMap();
            params.put("Status", "Status must be either ACTIVE or IN_ACTIVE");
            throw new BusinessException(ServiceError.INVALID_INPUT, null, params);
        }
    }

    private int validateAndParseMinusPoint(String value, String fieldLabel, StringBuilder errorBuilder) {
        if (StringUtils.isBlank(value)) {
            return 0;
        }
        String trimmed = value.trim();
        if (!trimmed.matches("\\d+")) {
            errorBuilder.append(fieldLabel).append(" must be numeric. ");
            return 0;
        }
        try {
            return Integer.parseInt(trimmed);
        } catch (NumberFormatException e) {
            errorBuilder.append(fieldLabel).append(" must be numeric. ");
            return 0;
        }
    }

    private LinkedHashMap<String, Object> createParamMap(String key, String value) {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put(key, value);
        return params;
    }
}