package com.dx.isecure.secure_service.dto.response;

import com.dx.isecure.secure_service.entity.constant.OrgState;

import java.time.LocalDate;

public interface OrganizationProjection {
    Integer getId();

    String getOrgCode();

    String getName();

    OrgState getState();

    LocalDate getStartDate();

    LocalDate getEndDate();

    Integer getEmployeeId();

    String getEmployeeNo();

    String getEmployeeName();

    String getEmployeeEmail();

    String getJobTitle();

    String getPhoneNo();

    LocalDate getEnteringDate();

    Integer getParentId();
}