package com.dx.isecure.secure_service.util;

import com.dx.isecure.secure_service.dto.EmployeeDto;
import com.dx.isecure.secure_service.dto.response.OrganizationProjection;
import com.dx.isecure.secure_service.dto.response.OrganizationRes;
import com.dx.isecure.secure_service.dto.response.ViolationListProjection;
import com.dx.isecure.secure_service.dto.response.ViolationListRes;
import org.springframework.data.domain.Page;

import java.util.*;

public class MapperResponseUtil {

    private MapperResponseUtil() {
        throw new IllegalStateException("Utility class");
    }

    public static Page<ViolationListRes> convertToViolationListRes(Page<ViolationListProjection> projections) {
        return projections.map(proj -> {
            ViolationListRes res = new ViolationListRes();
            res.setViolationId(proj.getViolationId());
            res.setViolationCode(proj.getViolationCode());
            res.setViolationCategory(proj.getViolationCategory());
            res.setViolationItem(proj.getViolationItem());
            res.setSeverity(proj.getSeverity());
            res.setEmployee(proj.getEmployee());
            res.setOrganization(proj.getOrganization());
            res.setNthViolation(proj.getNthViolation());
            res.setViolationTime(proj.getViolationTime());
            res.setReporter(proj.getReporter());
            res.setMinusPoint(proj.getMinusPoint());
            return res;
        });
    }

    public static List<OrganizationRes> mapToOrganizationResList(List<OrganizationProjection> projections) {
        return projections.stream()
                .map(MapperResponseUtil::mapToOrganizationRes)
                .toList();
    }

    public static OrganizationRes mapToOrganizationRes(OrganizationProjection projection) {
        return OrganizationRes.builder()
                .id(projection.getId())
                .orgCode(projection.getOrgCode())
                .orgPic(EmployeeDto.builder()
                        .id(projection.getEmployeeId())
                        .employeeNo(projection.getEmployeeNo())
                        .name(projection.getEmployeeName())
                        .email(projection.getEmployeeEmail())
                        .jodTitle(projection.getJobTitle())
                        .phoneNo(projection.getPhoneNo())
                        .enteringDate(projection.getEnteringDate())
                        .build())
                .name(projection.getName())
                .state(projection.getState())
                .startDate(projection.getStartDate())
                .endDate(projection.getEndDate())
                .build();
    }

    public static List<OrganizationRes> mapToOrganizationTreeRes(List<OrganizationProjection> projections) {
        Map<Integer, OrganizationRes> orgMap = new HashMap<>();
        List<OrganizationRes> orgRes = new ArrayList<>();

        projections.forEach(proj -> {
            EmployeeDto orgPic = proj.getEmployeeId() == null
                            ? null
                            : EmployeeDto.builder()
                                .id(proj.getEmployeeId())
                                .employeeNo(proj.getEmployeeNo())
                                .name(proj.getEmployeeName())
                                .email(proj.getEmployeeEmail())
                                .jodTitle(proj.getJobTitle())
                                .phoneNo(proj.getPhoneNo())
                                .enteringDate(proj.getEnteringDate())
                                .build();

            OrganizationRes org = OrganizationRes.builder()
                    .id(proj.getId())
                    .orgCode(proj.getOrgCode())
                    .name(proj.getName())
                    .state(proj.getState())
                    .startDate(proj.getStartDate())
                    .endDate(proj.getEndDate())
                    .orgPic(orgPic)
                    .children(new ArrayList<>())
                    .build();

            orgMap.put(org.getId(), org);
        });

        projections.forEach(proj -> {
            OrganizationRes org = orgMap.get(proj.getId());

            Optional.ofNullable(orgMap.get(proj.getParentId()))
                    .ifPresentOrElse(
                            parent -> parent.getChildren().add(org),
                            () -> orgRes.add(org)
                    );
        });

        return orgRes;
    }
}
