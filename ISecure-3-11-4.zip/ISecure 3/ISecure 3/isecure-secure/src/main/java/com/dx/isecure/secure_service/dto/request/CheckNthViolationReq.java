package com.dx.isecure.secure_service.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CheckNthViolationReq {
    @NotNull(message = "employeeId must not be null")
    private Integer employeeId;
    @NotNull(message = "violationItemId must not be null")
    private Integer violationItemId;
}
