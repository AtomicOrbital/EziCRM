package com.dx.isecure.secure_service.dto.response;

import lombok.Data;

@Data
public class ViolationCategoryResponse {
    private int id;
    private String code;
    private String name;
}
