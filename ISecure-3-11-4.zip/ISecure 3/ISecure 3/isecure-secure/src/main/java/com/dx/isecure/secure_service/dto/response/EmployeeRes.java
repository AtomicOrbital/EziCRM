package com.dx.isecure.secure_service.dto.response;

import com.dx.isecure.common.web.utils.constant.State;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EmployeeRes {
    Integer id;

    String employeeNo;

    String name;

    String email;

    String jobTitle;

    String phoneNo;

    LocalDate enteringDate;

    LocalDate leavingDate;

    State state;

    Integer accountId;

    String organization;

    // TODO: pending for api auth service
    // Role role;
}
