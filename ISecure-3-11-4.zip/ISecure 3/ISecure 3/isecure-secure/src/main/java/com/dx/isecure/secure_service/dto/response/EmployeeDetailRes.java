package com.dx.isecure.secure_service.dto.response;

import com.dx.isecure.common.web.utils.constant.State;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDetailRes {
    private Integer id;
    private String employeeNo;
    private String name;
    private String email;
    private String jobTitle;
    private String phoneNo;
    private LocalDate enteringDate;
    private LocalDate leavingDate;
    private State state;
    private Integer accountId;
    private Integer orgId;
    private String orgName;
}