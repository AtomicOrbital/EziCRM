package com.dx.isecure.secure_service.controller;

import com.dx.isecure.common.web.request.PagingReq;
import com.dx.isecure.common.web.response.Response;
import com.dx.isecure.common.web.response.ResponseUtils;
import com.dx.isecure.common.web.utils.constant.State;
import com.dx.isecure.secure_service.dto.request.EmployeeReq;
import com.dx.isecure.secure_service.dto.request.DeleteEmployeeReq;
import com.dx.isecure.secure_service.service.EmployeeService;
import com.dx.isecure.secure_service.service.FileService;
import jakarta.validation.Valid;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.dx.isecure.secure_service.constant.ExcelFileSrc.EMPLOYEE_FILENAME;

@RequiredArgsConstructor
@RestController
@RequestMapping("/employees")
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@CrossOrigin("*")
public class EmployeeController {
    EmployeeService employeeService;
    private FileService fileService;

    @GetMapping("")
    public ResponseEntity<Response> getEmployees(@RequestParam(name = "keySearch", required = false) String keySearch,
                                                 @RequestParam(name = "state", required = false) State state,
                                                 @ParameterObject PagingReq pagingReq) {
        return ResponseUtils.ok(employeeService.getEmployees(keySearch, state, pagingReq));
    }

    @PostMapping("")
    public ResponseEntity<Response> upsertEmployee(@Valid @RequestBody EmployeeReq employeeReq) {
        return ResponseUtils.ok(employeeService.upsertEmployee(employeeReq));
    }

    @DeleteMapping("")
    public ResponseEntity<Response> deleteEmployees(@RequestBody DeleteEmployeeReq deleteEmployeeReq) {
        employeeService.deleteEmployees(deleteEmployeeReq);
        return ResponseUtils.ok("Employees has been deleted", deleteEmployeeReq.getIds());
    }

    @GetMapping("/{employeeId}")
    public ResponseEntity<Response> getEmployeeDetail(
            @PathVariable("employeeId") Integer employeeId,
            @RequestParam(value = "isCode", defaultValue = "false") boolean isCode
    ) {
        return ResponseUtils.ok(employeeService.getEmployeeDetail(employeeId, isCode));
    }

    @GetMapping("/download-template")
    public ResponseEntity<Resource> downloadTemplate() {
        return fileService.downloadFile(EMPLOYEE_FILENAME);
    }

    @GetMapping("/export-employee")
    public ResponseEntity<Resource> exportEmployee(@RequestParam(name = "keySearch", required = false) String keySearch) {
        return employeeService.exportFile(EMPLOYEE_FILENAME, keySearch);
    }

    @GetMapping("/export-qr")
    public ResponseEntity<Response> exportQRCode(@RequestParam(name = "employeeIds", required = false) List<Integer> employeeIds) {
        return ResponseUtils.ok(employeeService.getMembersBase64(employeeIds));
    }
}
