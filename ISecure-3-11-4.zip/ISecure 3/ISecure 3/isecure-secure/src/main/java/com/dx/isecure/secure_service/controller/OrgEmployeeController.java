package com.dx.isecure.secure_service.controller;

import com.dx.isecure.common.web.request.PagingReq;
import com.dx.isecure.common.web.response.Response;
import com.dx.isecure.common.web.response.ResponseUtils;
import com.dx.isecure.secure_service.dto.request.DeleteEmployeeReq;
import com.dx.isecure.secure_service.dto.request.OrgEmployeesReq;
import com.dx.isecure.secure_service.service.OrgEmployeeService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springdoc.core.annotations.ParameterObject;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
@RequestMapping("/orgEmployees")
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@CrossOrigin("*")
public class OrgEmployeeController {
    OrgEmployeeService orgEmployeeService;

    @PostMapping("/{orgId}/employees")
    public ResponseEntity<Response> addEmployeesToOrganization(@PathVariable("orgId") Integer orgId, @RequestBody OrgEmployeesReq orgEmployeesReq) {
        orgEmployeeService.addEmployeesToOrganization(orgId, orgEmployeesReq);
        return ResponseUtils.ok("Employees : " + orgEmployeesReq.getIds() + " has been added to organization: " + orgId);
    }

    @DeleteMapping("")
    public ResponseEntity<Response> removeEmployeesFromOrg(@RequestBody DeleteEmployeeReq deleteEmployeeReq) {
        orgEmployeeService.removeEmployeesFromOrg(deleteEmployeeReq);
        return ResponseUtils.ok("Employees has been remove organization :", deleteEmployeeReq.getIds());
    }

    @GetMapping("")
    public ResponseEntity<Response> getEmployeesOfOrg(
            @RequestParam(name = "organizationId") Integer orgId,
            @RequestParam(name = "keySearch", required = false) String keySearch,
            @ParameterObject PagingReq pagingReq) {
        return ResponseUtils.ok(orgEmployeeService.getEmployeesOfOrg(orgId, keySearch, pagingReq));
    }
}
