package com.dx.isecure.secure_service.constant;

public class ExcelFileSrc {
    // File path
    public static final String SECURITY_STANDARD_TEMPLATE_PATH = "template/";

    // File name
    public static final String SECURITY_STANDARD_FILENAME = "security_standard_template.xlsx";
    public static final String EMPLOYEE_FILENAME = "employee_template.xlsx";
}
