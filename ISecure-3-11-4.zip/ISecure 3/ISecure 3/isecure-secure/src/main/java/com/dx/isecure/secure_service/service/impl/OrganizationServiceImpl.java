package com.dx.isecure.secure_service.service.impl;

import com.dx.isecure.common.web.exception.EntityNotFoundException;
import com.dx.isecure.common.web.exception.common.BusinessException;
import com.dx.isecure.common.web.exception.common.ServiceError;
import com.dx.isecure.common.web.utils.MappingHelper;
import com.dx.isecure.common.web.utils.constant.State;
import com.dx.isecure.secure_service.dto.OrganizationDto;
import com.dx.isecure.secure_service.dto.request.OrganizationReq;
import com.dx.isecure.secure_service.dto.response.OrganizationProjection;
import com.dx.isecure.secure_service.dto.response.OrganizationRes;
import com.dx.isecure.secure_service.entity.Employee;
import com.dx.isecure.secure_service.entity.Organization;
import com.dx.isecure.secure_service.entity.Period;
import com.dx.isecure.secure_service.entity.constant.OrgState;
import com.dx.isecure.secure_service.repository.EmployeeRepository;
import com.dx.isecure.secure_service.repository.OrgEmployeeRepository;
import com.dx.isecure.secure_service.repository.OrganizationRepository;
import com.dx.isecure.secure_service.repository.PeriodRepository;
import com.dx.isecure.secure_service.service.OrganizationService;
import com.dx.isecure.secure_service.util.BusinessUtil;
import com.dx.isecure.secure_service.util.MapperResponseUtil;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.modelmapper.internal.Pair;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class OrganizationServiceImpl implements OrganizationService {
    OrganizationRepository organizationRepository;

    EmployeeRepository employeeRepository;

    OrgEmployeeRepository orgEmployeeRepository;
    PeriodRepository periodRepository;
    MappingHelper mappingHelper;

    @Override
    @Transactional
    public OrganizationDto createOrganization(OrganizationReq organizationReq) {
        validateUniqueFields(organizationReq, null);

        Employee orgPic = null;
        if (organizationReq.getOrgPic() != null) {
            orgPic = employeeRepository.findByIdAndState(organizationReq.getOrgPic(), State.ACTIVE)
                    .orElseThrow(() -> new BusinessException(ServiceError.INACTIVE_EMPLOYEE_STATUS, null, null));
        }

        Organization organization = mappingHelper.map(organizationReq, Organization.class);

        setParentOrganization(organizationReq, organization);

        String newOrgCode = generateUniqueOrgCode();
        organization.setOrgCode(newOrgCode);

        setOrganizationState(organization, null);

        organization.setOrgPic(orgPic);

        organizationRepository.save(organization);

        return mappingHelper.map(organization, OrganizationDto.class);
    }

    @Override
    @Transactional
    public OrganizationDto updateOrganization(Integer id, OrganizationReq organizationReq) {
        var org = organizationRepository.getOrganizationById(id).orElseThrow(() -> new EntityNotFoundException(Organization.class.getSimpleName(), id.toString()));

        validateUniqueFields(organizationReq, id);

        mappingHelper.copyProperties(organizationReq, org);

        Employee newOrgPic = null;
        if (organizationReq.getOrgPic() != null) {
            newOrgPic = employeeRepository.findByIdAndState(organizationReq.getOrgPic(), State.ACTIVE)
                    .orElseThrow(() -> new BusinessException(ServiceError.INACTIVE_EMPLOYEE_STATUS, null, null));
        }

        org.setOrgPic(newOrgPic);

        setParentOrganization(organizationReq, org);

        setOrganizationState(org, null);

        organizationRepository.save(org);

        return mappingHelper.map(org, OrganizationDto.class);
    }

    @Override
    public void deleteOrganization(Integer id) {
        Organization organization = organizationRepository.getOrganizationById(id)
                .orElseThrow(() -> new EntityNotFoundException(Organization.class.getSimpleName(), id.toString()));

        organization.setDeletedAt(Instant.now());
        organization.setState(OrgState.IN_ACTIVE);
        // TODO

        organizationRepository.save(organization);
    }

    @Transactional
    @Override
    public List<OrganizationRes> getOrganizationList(Integer periodId) {
        Period period = resolvePeriod(periodId);
        List<OrganizationProjection> organizations = Boolean.TRUE.equals(BusinessUtil.isCurrentPeriod(period))
                ? organizationRepository.getOrganizationListInCurrentPeriod()
                : organizationRepository.getOrganizationListInPastPeriod(period.getId());

        return MapperResponseUtil.mapToOrganizationTreeRes(organizations);
    }

    private void setParentOrganization(OrganizationReq organizationReq, Organization organization) {
        if (organizationReq.getParentId() != null) {
            Organization parentOrg = organizationRepository.findById(organizationReq.getParentId())
                    .orElseThrow(() -> new BusinessException(ServiceError.PARENT_ORG_NOT_FOUND, null, null));
            organization.setParent(parentOrg);
        } else {
            organization.setParent(null);
        }
    }

    private void setOrganizationState(Organization organization, LocalDate currentDate){
        if(currentDate == null){
            currentDate = LocalDate.now();
        }

        boolean isInactive = organization.getStartDate().isAfter(currentDate) ||
                (organization.getEndDate() != null && !organization.getEndDate().isAfter(currentDate));

        organization.setState(isInactive ? OrgState.IN_ACTIVE : OrgState.ACTIVE);
    }

    private Period resolvePeriod(Integer periodId) {
        if (periodId == null) {
            return periodRepository.findBySpecificDate(LocalDate.now())
                    .orElseGet(this::createDefaultPeriod);
        }
        return periodRepository.findById(periodId)
                .orElseThrow(() -> new EntityNotFoundException(Period.class.getSimpleName(), periodId.toString()));
    }

    private Period createDefaultPeriod() {
        Pair<LocalDate, LocalDate> dateRange = BusinessUtil.getDateRangeFromSpecificDate(LocalDate.now());
        Period newPeriod = Period.builder()
                .periodStartDate(dateRange.getLeft())
                .periodEndDate(dateRange.getRight())
                .build();
        return periodRepository.save(newPeriod);
    }

    private void validateUniqueFields(OrganizationReq organizationReq, Integer currentId) {
        List<Object[]> duplicates = organizationRepository.findByOrgName(organizationReq.getName());

        for (Object[] result : duplicates) {
            String existingName = (String) result[0];
            Integer existingId = (Integer) result[1];

            if (currentId == null || !currentId.equals(existingId)) {
                if (organizationReq.getName() != null && organizationReq.getName().equals(existingName)) {
                    throw new BusinessException(ServiceError.DUPLICATE_ORGANIZATION_NAME, null, null);
                }
            }
        }
    }

    private String generateUniqueOrgCode(){
        String maxOrgCode = organizationRepository.findMaxOrgCode();
        int nextNumber;
        if (maxOrgCode == null) {
            nextNumber = 1;
        } else {
            nextNumber = Integer.parseInt(maxOrgCode.replace("ORG", "")) + 1;
        }

        String newOrgCode;
        do {
            newOrgCode = String.format("ORG%03d", nextNumber);
            nextNumber++;
        } while (organizationRepository.existsByOrgCode(newOrgCode));

        return newOrgCode;
    }
}
