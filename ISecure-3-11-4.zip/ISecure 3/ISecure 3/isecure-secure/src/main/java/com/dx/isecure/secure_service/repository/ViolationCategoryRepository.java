package com.dx.isecure.secure_service.repository;

import com.dx.isecure.secure_service.entity.ViolationCategory;
import com.dx.isecure.secure_service.service.ViolationCategoryProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface ViolationCategoryRepository extends JpaRepository<ViolationCategory, Integer> {

    @Query(value = "SELECT *, " +
            "NULL CREATED_AT, " +
            "NULL CREATED_BY, " +
            "NULL UPDATED_AT, " +
            "NULL UPDATED_BY, " +
            "NULL DELETED_AT, " +
            "NULL DELETED_BY " +
            "FROM VIOLATION_CATEGORY_BACKUP " +
            "WHERE PERIOD_ID = (:#{#periodId})", nativeQuery = true)
    List<ViolationCategory> getCategoryInPastPeriod(Integer periodId);

    @Query(value = "SELECT *, " +
            "NULL CREATED_AT, " +
            "NULL CREATED_BY, " +
            "NULL UPDATED_AT, " +
            "NULL UPDATED_BY, " +
            "NULL DELETED_AT, " +
            "NULL DELETED_BY " +
            "FROM VIOLATION_CATEGORY_BACKUP " +
            "WHERE PERIOD_ID = (:#{#periodId}) " +
            "AND ID = (:#{#categoryId})", nativeQuery = true)
    Optional<ViolationCategory> getCategoryInPastPeriodById(Integer categoryId, Integer periodId);

    @Query(
            value = "SELECT vc.ID AS categoryId, vc.CODE AS categoryCode, vc.NAME AS categoryName, vc.STATUS AS categoryStatus, " +
                    "vi.ID AS itemId, vi.CODE AS itemCode, vi.NAME AS itemName, vi.SEVERITY AS severity, " +
                    "vi.MINUS_POINTS_RULE AS minusPointsRule, vi.DEFINITION AS definition, vi.STATUS AS itemStatus " +
                    "FROM VIOLATION_CATEGORY vc " +
                    "LEFT JOIN VIOLATION_ITEM vi ON vi.VIOLATION_CATEGORY_ID = vc.ID " +
                    "WHERE (:keyword IS NULL OR :keyword = '' " +
                    "       OR LOWER(vc.CODE) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
                    "       OR LOWER(vc.NAME) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
                    "       OR LOWER(vi.CODE) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
                    "       OR LOWER(vi.NAME) LIKE LOWER(CONCAT('%', :keyword, '%'))) " +
                    "AND vc.DELETED_AT IS NULL " +
                    "AND (vi.DELETED_AT IS NULL OR vi.ID IS NULL)",
            nativeQuery = true
    )
    List<ViolationCategoryProjection> searchByKeyword(@Param("keyword") String keyword);


    @Query("select c from ViolationCategory c where c.deletedAt is null")
    List<ViolationCategory> findAll();

    Optional<ViolationCategory> findByCodeOrName(String code, String name);

    Optional<ViolationCategory> findByCode(String code);

    @Query("SELECT vc.code FROM ViolationCategory vc")
    List<String> findAllCodes();

    @Query("SELECT vc.name FROM ViolationCategory vc")
    List<String> findAllNames();

}
