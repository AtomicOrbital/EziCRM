package com.dx.isecure.secure_service.dto.response;

import lombok.*;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SecurityStandardResponse {
    Integer id;
    String code;
    String name;
    String status;
    String type;

    String severity;
    String minusPointsRule;
    String definition;

    List<ViolationItemResponse> children;

}
