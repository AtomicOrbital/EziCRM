package com.dx.isecure.secure_service.dto.response;

import com.dx.isecure.secure_service.entity.constant.Severity;

import java.time.LocalDateTime;

public interface ViolationListProjection {
    Integer getViolationId();

    String getViolationCode();

    String getViolationCategory();

    String getViolationItem();

    Severity getSeverity();

    String getEmployee();

    String getOrganization();

    Integer getNthViolation();

    LocalDateTime getViolationTime();

    String getReporter();

    Integer getMinusPoint();
}