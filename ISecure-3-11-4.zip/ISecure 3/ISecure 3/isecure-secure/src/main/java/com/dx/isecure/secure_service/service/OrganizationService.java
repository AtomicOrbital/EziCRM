package com.dx.isecure.secure_service.service;

import com.dx.isecure.secure_service.dto.OrganizationDto;
import com.dx.isecure.secure_service.dto.request.OrganizationReq;
import com.dx.isecure.secure_service.dto.response.OrganizationRes;

import java.util.List;

public interface OrganizationService {
    OrganizationDto createOrganization(OrganizationReq organizationReq);

    OrganizationDto updateOrganization(Integer id, OrganizationReq organizationReq);

    void deleteOrganization(Integer id);

    List<OrganizationRes> getOrganizationList(Integer periodId);
}
