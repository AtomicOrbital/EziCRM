package com.dx.isecure.secure_service.service;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.multipart.MultipartFile;

public interface ImportExcelStandardService {
    public void importExcel(MultipartFile file, HttpServletResponse response);
}
