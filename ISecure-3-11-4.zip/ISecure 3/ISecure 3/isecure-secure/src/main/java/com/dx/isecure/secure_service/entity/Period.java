package com.dx.isecure.secure_service.entity;

import com.dx.isecure.common.utils.auditaware.AuditEntity;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "PERIOD")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Period extends AuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "PERIOD_STR_DATE")
    private LocalDate periodStartDate;

    @Column(name = "PERIOD_END_DATE")
    private LocalDate periodEndDate;
}