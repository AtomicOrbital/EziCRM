package com.dx.isecure.secure_service.controller;

import com.dx.isecure.secure_service.service.FileService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static com.dx.isecure.secure_service.constant.ExcelFileSrc.SECURITY_STANDARD_FILENAME;

@RequiredArgsConstructor
@RestController
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@RequestMapping("/standards")
@CrossOrigin("*")


public class SecurityStandardController {
    private FileService fileService;
    @GetMapping("/download-template")
    public ResponseEntity<Resource> downloadTemplate() {
        return fileService.downloadFile(SECURITY_STANDARD_FILENAME);
    }
}
