package com.dx.isecure.secure_service.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.qrcode.QRCodeWriter;
import org.springframework.stereotype.Component;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Base64;
import java.util.Map;
import java.io.ByteArrayOutputStream;
import java.util.*;

@Component
public class Base64Util {

    private final ObjectMapper objectMapper;

    public Base64Util(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public String generateQRCodeBase64(Map<String, Object> data) {
        try {
            String jsonData = objectMapper.writeValueAsString(data);
            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            Map<EncodeHintType, Object> hintMap = new HashMap<>();
            hintMap.put(EncodeHintType.MARGIN, 1);
            BufferedImage qrImage = toBufferedImage(qrCodeWriter.encode(jsonData, BarcodeFormat.QR_CODE, 300, 300, hintMap));
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            ImageIO.write(qrImage, "PNG", outputStream);
            byte[] qrImageBytes = outputStream.toByteArray();

            return Base64.getEncoder().encodeToString(qrImageBytes);
        } catch (WriterException | IOException e) {
            throw new RuntimeException("Error generating QR code: " + e.getMessage(), e);
        }
    }

    private static BufferedImage toBufferedImage(com.google.zxing.common.BitMatrix matrix) {
        int width = matrix.getWidth();
        int height = matrix.getHeight();
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                image.setRGB(x, y, matrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
            }
        }
        return image;
    }

}

