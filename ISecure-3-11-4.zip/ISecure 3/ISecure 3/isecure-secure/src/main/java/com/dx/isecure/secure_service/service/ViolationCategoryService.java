package com.dx.isecure.secure_service.service;

import com.dx.isecure.secure_service.dto.request.SecurityStandardRequest;
import com.dx.isecure.secure_service.dto.request.ViolationCategoryUpdateRequest;
import com.dx.isecure.secure_service.dto.request.ViolationItemDeleteRequest;
import com.dx.isecure.secure_service.dto.response.SecurityStandardResponse;
import com.dx.isecure.secure_service.dto.response.ViolationCategoryParentResponse;
import com.dx.isecure.secure_service.dto.response.ViolationCategoryResponse;

import java.util.List;

public interface ViolationCategoryService {
    List<ViolationCategoryResponse> getAllViolationCategories();

    List<ViolationCategoryParentResponse> getAllViolationCategoriesWithItems(String keyword);

    SecurityStandardResponse createSecurityStandard(SecurityStandardRequest request);

    SecurityStandardResponse createViolationCategory(SecurityStandardRequest request);

    SecurityStandardResponse createViolationItem(SecurityStandardRequest securityStandardRequest);

    List<SecurityStandardResponse> updateBulkSecurityStandard(List<ViolationCategoryUpdateRequest> requests);

    SecurityStandardResponse updateSecurityStandard(Integer id, ViolationCategoryUpdateRequest request);

    SecurityStandardResponse updateViolationCategory(Integer id, ViolationCategoryUpdateRequest request);

    SecurityStandardResponse updateViolationItem(Integer id, ViolationCategoryUpdateRequest request);

    List<Integer> bulkDeleteSecurityStandard(List<ViolationItemDeleteRequest> deleteRequests);
}
