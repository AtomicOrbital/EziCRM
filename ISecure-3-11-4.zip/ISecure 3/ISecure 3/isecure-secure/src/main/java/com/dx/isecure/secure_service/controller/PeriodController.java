package com.dx.isecure.secure_service.controller;

import com.dx.isecure.common.web.response.Response;
import com.dx.isecure.common.web.response.ResponseUtils;
import com.dx.isecure.secure_service.service.PeriodService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RestController
@RequestMapping("/periods")
@CrossOrigin("*")
public class PeriodController {
    private final PeriodService periodService;

    @Operation(summary = "Get period list")
    @GetMapping("")
    public ResponseEntity<Response> getPeriodList() {
        return ResponseUtils.ok(periodService.getPeriodList());
    }
}
