package com.dx.isecure.secure_service.dto.request;

import com.dx.isecure.common.web.utils.validator.annotation.DateRange;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@DateRange(startField = "startDate", endField = "endDate", message = "End date must be after start date")
public class OrganizationReq {

    @NotBlank(message = "Name organization must not be blank")
    String name;

    Integer orgPic;

    @NotNull(message = "Start date must not be null")
    LocalDate startDate;

    LocalDate endDate;

    Integer parentId;
}
