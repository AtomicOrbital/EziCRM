package com.dx.isecure.secure_service.dto.response;

import com.dx.isecure.common.client.storage.dto.AttachmentDto;
import com.dx.isecure.secure_service.dto.EmployeeDto;
import com.dx.isecure.secure_service.entity.constant.DefaultValue;
import com.dx.isecure.secure_service.entity.constant.Severity;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.Instant;
import java.util.List;

@Data
public class ViolationDetailRes {
    private Integer id;
    private String violationCode;
    private String category;
    private String violationItem;
    private Severity severity;
    private EmployeeDto employee;
    private Integer nthViolation;
    private Integer minusPoints;
    private String description;
    private EmployeeDto reportBy;
    private List<AttachmentDto> evidences;

    @JsonFormat(pattern = DefaultValue.DATE_TIME_FORMAT, timezone = "UTC")
    private Instant violationTime;
}
