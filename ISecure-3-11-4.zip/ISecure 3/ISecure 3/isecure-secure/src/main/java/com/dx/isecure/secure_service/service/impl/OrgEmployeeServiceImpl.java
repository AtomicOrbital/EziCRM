package com.dx.isecure.secure_service.service.impl;

import com.dx.isecure.common.web.exception.EmployeeHadOrgException;
import com.dx.isecure.common.web.exception.EntityNotFoundException;
import com.dx.isecure.common.web.exception.InactiveEmployeeException;
import com.dx.isecure.common.web.request.PagingReq;
import com.dx.isecure.common.web.utils.constant.State;
import com.dx.isecure.secure_service.dto.request.DeleteEmployeeReq;
import com.dx.isecure.secure_service.dto.request.OrgEmployeesReq;
import com.dx.isecure.secure_service.dto.response.EmployeeRes;
import com.dx.isecure.secure_service.entity.Employee;
import com.dx.isecure.secure_service.entity.OrgEmployee;
import com.dx.isecure.secure_service.entity.Organization;
import com.dx.isecure.secure_service.repository.EmployeeRepository;
import com.dx.isecure.secure_service.repository.OrgEmployeeRepository;
import com.dx.isecure.secure_service.repository.OrganizationRepository;
import com.dx.isecure.secure_service.service.OrgEmployeeService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class OrgEmployeeServiceImpl implements OrgEmployeeService {
    OrganizationRepository organizationRepository;

    EmployeeRepository employeeRepository;

    OrgEmployeeRepository orgEmployeeRepository;

    @Transactional
    @Override
    public void addEmployeesToOrganization(Integer orgId, OrgEmployeesReq orgEmployeesReq) {
        Organization organization = organizationRepository.getOrganizationById(orgId)
                .orElseThrow(() -> new EntityNotFoundException(Organization.class.getSimpleName(), orgId.toString()));

        if (orgEmployeesReq.getIds() == null || orgEmployeesReq.getIds().isEmpty())
            throw new EntityNotFoundException(Employee.class.getSimpleName(), orgEmployeesReq.getIds().toString());

        List<Employee> activeEmployees = employeeRepository.findAllByIdNotInCurrentOrg(orgEmployeesReq.getIds(), orgId);

        List<Integer> inactiveEmployeeIds = activeEmployees.stream()
                .filter(e -> e.getState() == State.IN_ACTIVE)
                .map(Employee::getId)
                .toList();

        if (!inactiveEmployeeIds.isEmpty())
            throw new InactiveEmployeeException(inactiveEmployeeIds);

        List<Integer> employeeIds = activeEmployees.stream()
                .map(Employee::getId)
                .toList();

        List<Integer> alreadyAssignedEmployeeIds = orgEmployeeRepository.findAssignedEmployeeIds(employeeIds, organization.getId());
        if (!alreadyAssignedEmployeeIds.isEmpty()) {
            throw new EmployeeHadOrgException(alreadyAssignedEmployeeIds);
        }

        List<OrgEmployee> orgEmployees = activeEmployees.stream()
                .map(employee -> OrgEmployee.builder()
                        .employee(employee)
                        .organization(organization)
                        .timeJoin(LocalDate.now())
                        .timeLeft(null)
                        .build())
                .toList();

        orgEmployeeRepository.saveAll(orgEmployees);
    }

    @Override
    @Transactional
    public void removeEmployeesFromOrg(DeleteEmployeeReq deleteEmployeeReq) {
        if (deleteEmployeeReq.getIds() == null || deleteEmployeeReq.getIds().isEmpty()){
            throw new EntityNotFoundException(Employee.class.getSimpleName(), deleteEmployeeReq.getIds().toString());
        }

        List<Employee> employees = employeeRepository.findAllById(deleteEmployeeReq.getIds());
        Set<Integer> foundIds = employees.stream().map(Employee::getId).collect(Collectors.toSet());

        List<Integer> notFoundIds = deleteEmployeeReq.getIds().stream()
                .filter(id -> !foundIds.contains(id))
                .toList();

        if (!notFoundIds.isEmpty()) {
            throw new EntityNotFoundException(Employee.class.getSimpleName(), notFoundIds.toString());
        }

        orgEmployeeRepository.updateDeletedAtByEmployeeIds(Instant.now(), LocalDate.now(), deleteEmployeeReq.getIds());
    }

    @Override
    public Page<EmployeeRes> getEmployeesOfOrg(Integer orgId, String keySearch, PagingReq pagingReq) {
        Organization org = organizationRepository.findById(orgId)
                .orElseThrow(() -> new EntityNotFoundException(Organization.class.getSimpleName(), orgId.toString()));

        List<Integer> orgIds = organizationRepository.getTreeOrgByParentId(org.getId())
                .stream().map(Organization::getId)
                .toList();

        return employeeRepository.findAllEmployeesOfOrgByCriteria(orgIds, keySearch, pagingReq.makePageable());
    }
}
