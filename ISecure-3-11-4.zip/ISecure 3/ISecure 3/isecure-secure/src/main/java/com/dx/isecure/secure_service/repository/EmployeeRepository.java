package com.dx.isecure.secure_service.repository;

import com.dx.isecure.common.web.utils.constant.State;
import com.dx.isecure.secure_service.dto.response.EmployeeDetailRes;
import com.dx.isecure.secure_service.dto.response.EmployeeRes;
import com.dx.isecure.secure_service.entity.Employee;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
    @Query(value = "SELECT new com.dx.isecure.secure_service.dto.response.EmployeeRes(e.id, " +
            "e.employeeNo, " +
            "e.name, " +
            "e.email, " +
            "e.jobTitle, " +
            "e.phoneNo, " +
            "e.enteringDate, " +
            "e.leavingDate, " +
            "e.state, " +
            "e.accountId, " +
            "org.name) " +
            "FROM Employee e " +
            "LEFT JOIN OrgEmployee org_e ON org_e.employee.id = e.id AND org_e.timeLeft IS NULL " +
            "LEFT JOIN Organization org ON org.id = org_e.organization.id " +
            "WHERE e.deletedAt IS NULL " +
            "AND (:keySearch IS NULL  " +
            "OR e.employeeNo LIKE CONCAT('%', :keySearch, '%') " +
            "OR e.name LIKE CONCAT('%', :keySearch, '%'))"+
            "AND (:state IS NULL OR e.state = :state)")
    Page<EmployeeRes> findAllByCriteria(@Param("keySearch") String keySearch,
                                        @Param("state") State state,
                                        Pageable pageable);

    Optional<Employee> findByIdAndState(Integer employeeId, State state);

    @Query("SELECT e FROM Employee e " +
            "LEFT JOIN OrgEmployee org_e " +
            "ON e.id = org_e.employee.id " +
            "AND org_e.timeLeft IS NULL " +
            "WHERE e.deletedAt IS NULL " +
            "AND e.id IN :ids " +
            "AND (org_e.organization.id <> :orgId OR org_e.id is NULL)")
    List<Employee> findAllByIdNotInCurrentOrg(Iterable<Integer> ids, @Param("orgId") Integer orgId);

    @Query( "SELECT CASE WHEN COUNT(org_e) > 0 THEN FALSE ELSE TRUE END " +
            "FROM OrgEmployee org_e " +
            "WHERE org_e.employee.id = :employeeId AND org_e.timeLeft is NULL ")
    Boolean IsNotInOrganization(@Param("employeeId") Integer employeeId);

    @Modifying
    @Transactional
    @Query("UPDATE Employee e SET e.deletedAt = :deletedAt, e.state = 'IN_ACTIVE' WHERE e.id IN :employeeIds")
    void updateDeletedAtByIds(@Param("deletedAt") Instant deletedAt,
                              @Param("employeeIds") List<Integer> employeeIds);

    @Query(value = "SELECT new com.dx.isecure.secure_service.dto.response.EmployeeRes(e.id, " +
            "e.employeeNo, " +
            "e.name, " +
            "e.email, " +
            "e.jobTitle, " +
            "e.phoneNo, " +
            "e.enteringDate, " +
            "e.leavingDate, " +
            "e.state, " +
            "e.accountId, " +
            "org.name) " +
            "FROM Employee e " +
            "LEFT JOIN OrgEmployee org_e ON org_e.employee.id = e.id AND org_e.timeLeft IS NULL " +
            "LEFT JOIN Organization org ON org.id = org_e.organization.id " +
            "WHERE e.deletedAt IS NULL " +
            "AND org.id IN :orgIds " +
            "AND (:keySearch IS NULL " +
            "OR e.employeeNo LIKE CONCAT('%', :keySearch, '%') " +
            "OR e.name LIKE CONCAT('%', :keySearch, '%'))")
    Page<EmployeeRes> findAllEmployeesOfOrgByCriteria(@Param("orgIds") List<Integer> orgIds,
                                        @Param("keySearch") String keySearch,
                                        Pageable pageable);

    boolean existsByEmployeeNo(String employeeNo);
    Optional<Employee> findByEmployeeNo(String employeeNo);

    boolean existsByEmail(String email);
    Optional<Employee> findByEmail(String email);

    boolean existsByPhoneNo(String phoneNo);
    Optional<Employee> findByPhoneNo(String phoneNo);

    @Query("SELECT new com.dx.isecure.secure_service.dto.response.EmployeeDetailRes(" +
            "e.id, e.employeeNo, e.name, e.email, e.jobTitle, e.phoneNo, e.enteringDate, " +
            "e.leavingDate, e.state, e.accountId, org.id, org.name) " +
            "FROM Employee e " +
            "LEFT JOIN OrgEmployee org_e ON org_e.employee.id = e.id AND org_e.timeLeft IS NULL " +
            "LEFT JOIN Organization org ON org.id = org_e.organization.id " +
            "WHERE e.deletedAt IS NULL " +
            "AND e.id = :employeeId")
    Optional<EmployeeDetailRes> getDetailById(@Param("employeeId") Integer employeeId);

    @Query("SELECT new com.dx.isecure.secure_service.dto.response.EmployeeDetailRes(" +
            "e.id, e.employeeNo, e.name, e.email, e.jobTitle, e.phoneNo, e.enteringDate, " +
            "e.leavingDate, e.state, e.accountId, org.id, org.name) " +
            "FROM Employee e " +
            "LEFT JOIN OrgEmployee org_e ON org_e.employee.id = e.id AND org_e.timeLeft IS NULL " +
            "LEFT JOIN Organization org ON org.id = org_e.organization.id " +
            "WHERE e.deletedAt IS NULL " +
            "AND e.employeeNo = :employeeNo")
    Optional<EmployeeDetailRes> getDetailByCode(@Param("employeeNo") String employeeNo);


    @Query(value = "SELECT new com.dx.isecure.secure_service.dto.response.EmployeeRes(e.id, " +
            "e.employeeNo, " +
            "e.name, " +
            "e.email, " +
            "e.jobTitle, " +
            "e.phoneNo, " +
            "e.enteringDate, " +
            "e.leavingDate, " +
            "e.state, " +
            "e.accountId, " +
            "org.name) " +
            "FROM Employee e " +
            "LEFT JOIN OrgEmployee org_e ON org_e.employee.id = e.id AND org_e.timeLeft IS NULL " +
            "LEFT JOIN Organization org ON org.id = org_e.organization.id " +
            "WHERE e.deletedAt IS NULL " +
            "AND (:keySearch IS NULL  " +
            "OR e.employeeNo LIKE CONCAT('%', :keySearch, '%') " +
            "OR e.name LIKE CONCAT('%', :keySearch, '%'))")
    List<EmployeeRes> findAllEmployeeWithoutPage(@Param("keySearch") String keySearch);

    @Query("SELECT new com.dx.isecure.secure_service.dto.response.EmployeeDetailRes(" +
            "e.id, e.employeeNo, e.name, e.email, e.jobTitle, e.phoneNo, e.enteringDate, " +
            "e.leavingDate, e.state, e.accountId, org.id, org.name) " +
            "FROM Employee e " +
            "LEFT JOIN OrgEmployee org_e ON org_e.employee.id = e.id AND org_e.timeLeft IS NULL " +
            "LEFT JOIN Organization org ON org.id = org_e.organization.id " +
            "WHERE e.deletedAt IS NULL " +
            "AND e.id IN :employeeIds")
    List<EmployeeDetailRes> getAllMembersByIds(@Param("employeeIds") List<Integer> employeeIds);
}
