package com.dx.isecure.secure_service.controller;

import com.dx.isecure.common.web.response.Response;
import com.dx.isecure.common.web.response.ResponseUtils;
import com.dx.isecure.secure_service.dto.request.OrganizationReq;
import com.dx.isecure.secure_service.service.OrganizationService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
@RequestMapping("/organizations")
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@CrossOrigin("*")
public class OrganizationController {
    OrganizationService organizationService;

    @PostMapping("")
    public ResponseEntity<Response> createOrganization(@Valid @RequestBody OrganizationReq organizationReq ) {
        return ResponseUtils.ok(organizationService.createOrganization(organizationReq));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Response> updateOrganization(@PathVariable("id") Integer id,@Valid @RequestBody OrganizationReq organizationReq) {
        return  ResponseUtils.ok(organizationService.updateOrganization(id, organizationReq));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Response> deleteOrganization(@PathVariable("id") Integer id) {
        organizationService.deleteOrganization(id);
        return ResponseUtils.ok("Organization has been deleted: " + id);
    }

    @Operation(summary = "Get organization list in period")
    @GetMapping("")
    public ResponseEntity<Response> getOrganizationList(@RequestParam(name = "periodId", required = false) Integer periodId) {
        return ResponseUtils.ok(organizationService.getOrganizationList(periodId));
    }
}
