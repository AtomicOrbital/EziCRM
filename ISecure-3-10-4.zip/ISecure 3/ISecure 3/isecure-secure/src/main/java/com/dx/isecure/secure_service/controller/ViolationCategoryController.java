package com.dx.isecure.secure_service.controller;

import com.dx.isecure.common.web.exception.common.ServiceError;
import com.dx.isecure.common.web.request.PagingReq;
import com.dx.isecure.common.web.response.ErrorResponse;
import com.dx.isecure.common.web.response.ResponseUtils;
import com.dx.isecure.secure_service.dto.request.SecurityStandardRequest;
import com.dx.isecure.secure_service.dto.request.ViolationCategoryUpdateRequest;
import com.dx.isecure.secure_service.dto.request.ViolationItemDeleteRequest;
import com.dx.isecure.secure_service.dto.response.SecurityStandardResponse;
import com.dx.isecure.secure_service.dto.response.ViolationCategoryResponse;
import com.dx.isecure.secure_service.service.ViolationCategoryService;
import com.dx.isecure.secure_service.service.impl.ImportExcelServiceImpl;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Collections;
import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/violation-category")
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@CrossOrigin("*")
public class ViolationCategoryController {
    ViolationCategoryService violationCategoryService;
    ImportExcelServiceImpl importExcelService;

    @GetMapping
    public ResponseEntity<?> getAllViolationCategories() {
        List<ViolationCategoryResponse> categories = violationCategoryService.getAllViolationCategories();
        return ResponseUtils.ok(categories);
    }

    @GetMapping("/with-items")
    public ResponseEntity<?> getAllViolationCategoriesWithItems(
            @RequestParam(value = "keyword", required = false) String keyword) {
        var pageResult = violationCategoryService.getAllViolationCategoriesWithItems(keyword);
        return ResponseEntity.ok(pageResult);
    }

    @PostMapping
    public ResponseEntity<?> createSecurityStandard(@RequestBody @Valid SecurityStandardRequest request) {
        SecurityStandardResponse created = violationCategoryService.createSecurityStandard(request);
        return ResponseUtils.ok("Created successfully", created);
    }

    @PutMapping("/bulk-update")
    public ResponseEntity<?> updateCategoryWithItems(@RequestBody List<ViolationCategoryUpdateRequest> categoryRequests) {
        List<SecurityStandardResponse> updated = violationCategoryService.updateBulkSecurityStandard(categoryRequests);
        return ResponseUtils.ok("Bulk update successfully", updated);
    }

    @DeleteMapping("/bulk-delete")
    public ResponseEntity<?> deleteCategoryAndItems(@RequestBody List<ViolationItemDeleteRequest> deleteRequestList) {
        List<Integer> deleted = violationCategoryService.bulkDeleteSecurityStandard(deleteRequestList);
        return ResponseUtils.ok("Bulk delete successfully", deleted);
    }



    @PostMapping(value = "/import-excel/security-standard", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> importExcel(@RequestPart("file") MultipartFile file,
                                         HttpServletResponse response) {
        try {
            importExcelService.importExcel(file, response);
            return ResponseUtils.ok("Excel import completed successfully with error messages", null);
        } catch (Exception e) {
//            return ResponseUtils.internalErr(
//                    new ErrorResponse(ServiceError.FILE_PROCESSING_ERROR, e.getMessage(), Collections.emptyMap())
//            );
            return null;
        }
    }
}

