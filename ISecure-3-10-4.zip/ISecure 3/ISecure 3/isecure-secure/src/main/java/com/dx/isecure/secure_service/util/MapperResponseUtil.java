package com.dx.isecure.secure_service.util;

import com.dx.isecure.secure_service.dto.EmployeeDto;
import com.dx.isecure.secure_service.dto.response.OrganizationProjection;
import com.dx.isecure.secure_service.dto.response.OrganizationRes;
import com.dx.isecure.secure_service.dto.response.ViolationListProjection;
import com.dx.isecure.secure_service.dto.response.ViolationListRes;
import org.springframework.data.domain.Page;

import java.util.List;

public class MapperResponseUtil {

    private MapperResponseUtil() {
        throw new IllegalStateException("Utility class");
    }

    public static Page<ViolationListRes> convertToViolationListRes(Page<ViolationListProjection> projections) {
        return projections.map(proj -> {
            ViolationListRes res = new ViolationListRes();
            res.setViolationId(proj.getViolationId());
            res.setViolationCategory(proj.getViolationCategory());
            res.setViolationItem(proj.getViolationItem());
            res.setSeverity(proj.getSeverity());
            res.setEmployee(proj.getEmployee());
            res.setOrganization(proj.getOrganization());
            res.setNthViolation(proj.getNthViolation());
            res.setViolationTime(proj.getViolationTime());
            res.setReporter(proj.getReporter());
            res.setMinusPoint(proj.getMinusPoint());
            return res;
        });
    }

    public static List<OrganizationRes> mapToOrganizationResList(List<OrganizationProjection> projections) {
        return projections.stream()
                .map(MapperResponseUtil::mapToOrganizationRes)
                .toList();
    }

    public static OrganizationRes mapToOrganizationRes(OrganizationProjection projection) {
        return OrganizationRes.builder()
                .id(projection.getId())
                .orgCode(projection.getOrgCode())
                .orgPic(EmployeeDto.builder()
                        .id(projection.getEmployeeId())
                        .employeeNo(projection.getEmployeeNo())
                        .name(projection.getEmployeeName())
                        .email(projection.getEmployeeEmail())
                        .jodTitle(projection.getJobTitle())
                        .phoneNo(projection.getPhoneNo())
                        .enteringDate(projection.getEnteringDate())
                        .build())
                .name(projection.getName())
                .state(projection.getState())
                .startDate(projection.getStartDate())
                .endDate(projection.getEndDate())
                .build();
    }
}
