package com.dx.isecure.secure_service.service.impl;

import com.dx.isecure.common.web.exception.common.BusinessException;
import com.dx.isecure.common.web.exception.common.ServiceError;
import com.dx.isecure.common.web.utils.MappingHelper;
import com.dx.isecure.common.web.utils.constant.State;
import com.dx.isecure.secure_service.dto.request.SecurityStandardRequest;
import com.dx.isecure.secure_service.dto.request.ViolationCategoryUpdateRequest;
import com.dx.isecure.secure_service.dto.request.ViolationItemDeleteRequest;
import com.dx.isecure.secure_service.dto.response.SecurityStandardResponse;
import com.dx.isecure.secure_service.dto.response.ViolationCategoryParentResponse;
import com.dx.isecure.secure_service.dto.response.ViolationCategoryResponse;
import com.dx.isecure.secure_service.dto.response.ViolationItemResponse;
import com.dx.isecure.secure_service.entity.ViolationCategory;
import com.dx.isecure.secure_service.entity.ViolationItem;
import com.dx.isecure.secure_service.entity.constant.OrgState;
import com.dx.isecure.secure_service.entity.constant.SecurityStandardType;
import com.dx.isecure.secure_service.entity.constant.Severity;
import com.dx.isecure.secure_service.repository.ViolationCategoryRepository;
import com.dx.isecure.secure_service.repository.ViolationItemRepository;
import com.dx.isecure.secure_service.service.ViolationCategoryProjection;
import com.dx.isecure.secure_service.service.ViolationCategoryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class ViolationCategoryServiceimpl implements ViolationCategoryService {
    private final ViolationCategoryRepository violationCategoryRepository;
    private final ViolationItemRepository violationItemRepository;
    private final MappingHelper mappingHelper;

    @Override
    public List<ViolationCategoryResponse> getAllViolationCategories() {
        List<ViolationCategory> violationCategories = violationCategoryRepository.findAll();
        return violationCategories.stream().map(violationCategory -> mappingHelper.map(violationCategory, ViolationCategoryResponse.class)).collect(Collectors.toList());
    }

    @Override
    public List<ViolationCategoryParentResponse> getAllViolationCategoriesWithItems(String keyword) {
        List<ViolationCategoryProjection> projections = violationCategoryRepository.searchByKeyword(keyword);
        Map<Integer, ViolationCategoryParentResponse> categoryMap = new HashMap<>();

        for (ViolationCategoryProjection projection : projections) {
            Integer categoryId = projection.getCategoryId();

            if (!categoryMap.containsKey(categoryId)) {
                ViolationCategoryParentResponse categoryResponse = new ViolationCategoryParentResponse();
                categoryResponse.setId(categoryId);
                categoryResponse.setCode(projection.getCategoryCode());
                categoryResponse.setName(projection.getCategoryName());
                categoryResponse.setStatus(projection.getCategoryStatus());
                categoryResponse.setChildren(new ArrayList<>());

                categoryMap.put(categoryId, categoryResponse);
            }

            if (projection.getItemId() != null) {
                ViolationItemResponse itemResponse = new ViolationItemResponse();
                itemResponse.setId(projection.getItemId());
                itemResponse.setCode(projection.getItemCode());
                itemResponse.setName(projection.getItemName());
                itemResponse.setSeverity(projection.getSeverity());
                itemResponse.setMinusPointsRule(projection.getMinusPointsRule());
                itemResponse.setDefinition(projection.getDefinition());
                itemResponse.setStatus(projection.getItemStatus());

                categoryMap.get(categoryId).getChildren().add(itemResponse);
            }
        }

        List<ViolationCategoryParentResponse> responseList = new ArrayList<>(categoryMap.values());

        return responseList;
    }

    @Override
    public SecurityStandardResponse createSecurityStandard(SecurityStandardRequest request) {
        if (SecurityStandardType.CATEGORY.name().equalsIgnoreCase(request.getType())) {
            return createViolationCategory(request);
        } else if (SecurityStandardType.ITEM.name().equalsIgnoreCase(request.getType())) {
            return createViolationItem(request);
        } else {
            throw new BusinessException(ServiceError.INVALID_INPUT, null, null);
        }
    }

    @Transactional
    @Override
    public SecurityStandardResponse createViolationCategory(SecurityStandardRequest request) {
        // check code, name, status
        if (StringUtils.isBlank(request.getCode()) || StringUtils.isBlank(request.getStatus())) {
            throw new BusinessException(ServiceError.REQUIRED_CODE_AND_NAME, null, null);
        }
        if (StringUtils.isBlank(request.getStatus())) {
            throw new BusinessException(ServiceError.REQUIRED_VIOLATION_CATEGORY, null, null);
        }

        Optional<ViolationCategory> existingCat =
                violationCategoryRepository.findByCodeOrName(request.getCode(), request.getName());
        if (existingCat.isPresent()) {
            throw new BusinessException(ServiceError.DUPLICATE_ENTRY, null, null);
        }

        ViolationCategory category = new ViolationCategory();
        category.setCode(request.getCode());
        category.setName(request.getName());
        category.setStatus(State.valueOf(request.getStatus()));
        violationCategoryRepository.save(category);

        // mapping to dto
        SecurityStandardResponse response = mappingHelper.map(category, SecurityStandardResponse.class);
        response.setType(SecurityStandardType.CATEGORY.name());
        // if not found children
        if (response.getChildren() == null) {
            response.setChildren(new ArrayList<>());
        }
        return response;
    }

    @Transactional
    @Override
    public SecurityStandardResponse createViolationItem(SecurityStandardRequest securityStandardRequest) {
        // check choose parent
        if (securityStandardRequest.getViolationCategoryId() == null) {
            throw new BusinessException(ServiceError.REQUIRED_VIOLATION_CATEGORY, null, null);
        }

        // check duplicate code and name
        Optional<ViolationItem> violationItemOptional = violationItemRepository.findByCodeOrName(securityStandardRequest.getCode(), securityStandardRequest.getName());
        if (violationItemOptional.isPresent()) {
            throw new BusinessException(ServiceError.DUPLICATE_ENTRY, null, null);
        }

        ViolationCategory category = violationCategoryRepository.findById(securityStandardRequest.getViolationCategoryId()).orElseThrow(() -> new BusinessException(ServiceError.ENTITY_NOT_FOUND, null, null));

        // list minus point
        List<Integer> minusPointRule = normalizeMinusPoints(securityStandardRequest.getMinusPoints());

        ViolationItem violationItem = mappingHelper.map(securityStandardRequest, ViolationItem.class);
        violationItem.setViolationCategory(category);
        violationItem.setName(securityStandardRequest.getName());
        violationItem.setCode(securityStandardRequest.getCode());
        violationItem.setStatus(State.valueOf(securityStandardRequest.getStatus()));
        violationItem.setSeverity(Severity.valueOf(securityStandardRequest.getSeverity()));
        violationItem.setMinusPointsRule(minusPointRule.stream().map(String::valueOf).collect(Collectors.joining("/")));
        violationItem = violationItemRepository.save(violationItem);

        // after create, load list violation item of violation category
        List<ViolationItem> childrenItems = violationItemRepository.findByViolationCategoryId(category.getId());
        List<ViolationItemResponse> children = mappingHelper.mapList(childrenItems, ViolationItemResponse.class);

        // mappging to dto
        SecurityStandardResponse response = mappingHelper.map(violationItem, SecurityStandardResponse.class);
        response.setType(SecurityStandardType.ITEM.name());
        if (children == null) {
            response.setChildren(new ArrayList<>());
        } else {
            response.setChildren(children);
        }
        return response;
    }

    @Transactional
    @Override
    public List<SecurityStandardResponse> updateBulkSecurityStandard(List<ViolationCategoryUpdateRequest> requests) {
        List<SecurityStandardResponse> responses = new ArrayList<>();
        for (ViolationCategoryUpdateRequest req : requests) {
            if (req.getId() == null) {
                LinkedHashMap<String, Object> params = new LinkedHashMap<>();
                params.put("id", "Missing id in request");
                throw new BusinessException(ServiceError.INVALID_INPUT, null, params);
            }
            SecurityStandardResponse resp = updateSecurityStandard(req.getId(), req);
            responses.add(resp);
        }
        return responses;
    }

    @Transactional
    @Override
    public SecurityStandardResponse updateSecurityStandard(Integer id, ViolationCategoryUpdateRequest request) {
        if (SecurityStandardType.CATEGORY.name().equalsIgnoreCase(request.getType())) {
            return updateViolationCategory(id, request);
        } else if (SecurityStandardType.ITEM.name().equalsIgnoreCase(request.getType())) {
            return updateViolationItem(id, request);
        } else {
            LinkedHashMap<String, Object> params = new LinkedHashMap<>();
            params.put("type", request.getType());
            throw new BusinessException(ServiceError.INVALID_INPUT, null, params);
        }
    }

    @Transactional
    @Override
    public SecurityStandardResponse updateViolationCategory(Integer id, ViolationCategoryUpdateRequest request) {
        ViolationCategory category = violationCategoryRepository.findById(id)
                .orElseThrow(() -> {
                    LinkedHashMap<String, Object> params = new LinkedHashMap<>();
                    params.put("CategoryId", id.toString());
                    return new BusinessException(ServiceError.ENTITY_NOT_FOUND, null, params);
                });

        if (StringUtils.isNotBlank(request.getCode())) {
            category.setCode(request.getCode());
        }
        if (StringUtils.isNotBlank(request.getName())) {
            category.setName(request.getName());
        }
        if (StringUtils.isNotBlank(request.getStatus())) {
            category.setStatus(State.valueOf(request.getStatus()));
        }
        violationCategoryRepository.save(category);

        // if category parent is inactive , the child in the category is also inactive
        if (OrgState.IN_ACTIVE.name().equalsIgnoreCase(request.getStatus())) {
            List<ViolationItem> childrens = violationItemRepository.findByViolationCategoryId(request.getId());
            for (ViolationItem child : childrens) {
                child.setStatus(State.valueOf(OrgState.IN_ACTIVE.name()));
                violationItemRepository.save(child);
            }
        }

        // Map to DTO response
        SecurityStandardResponse response = mappingHelper.map(category, SecurityStandardResponse.class);
        response.setType(SecurityStandardType.CATEGORY.name());
        // if not found children
        if (response.getChildren() == null) {
            response.setChildren(new ArrayList<>());
        }
        return response;
    }

    @Transactional
    @Override
    public SecurityStandardResponse updateViolationItem(Integer id, ViolationCategoryUpdateRequest request) {
        ViolationItem item = violationItemRepository.findById(id)
                .orElseThrow(() -> {
                    LinkedHashMap<String, Object> params = new LinkedHashMap<>();
                    params.put("ItemId", id.toString());
                    return new BusinessException(ServiceError.ENTITY_NOT_FOUND, null, params);
                });

        List<Integer> minusPointsRule = normalizeMinusPoints(request.getMinusPoints());

        if (StringUtils.isNotBlank(request.getCode())) {
            item.setCode(request.getCode());
        }
        if (StringUtils.isNotBlank(request.getName())) {
            item.setName(request.getName());
        }
        if (StringUtils.isNotBlank(request.getStatus())) {
            item.setStatus(State.valueOf(request.getStatus()));
        }
        if (StringUtils.isNotBlank(request.getSeverity())) {
            item.setSeverity(Severity.valueOf(request.getSeverity()));
        }
        if (StringUtils.isNotBlank(request.getDefinition())) {
            item.setDefinition(request.getDefinition());
        }
        if (request.getMinusPoints() != null && !request.getMinusPoints().isEmpty()) {
            String minusPointRuleString = minusPointsRule.stream()
                    .map(String::valueOf)
                    .collect(Collectors.joining("/"));
            item.setMinusPointsRule(minusPointRuleString);
        }
        if (StringUtils.isNotBlank(request.getDefinition())) {
            item.setDefinition(request.getDefinition());
        }

        violationItemRepository.save(item);

        // After update, reload the item's parent Category and the list of child Items
//        ViolationCategory parentCategory = item.getViolationCategory();
        // Map Category to response DTO
//        SecurityStandardResponse response = mappingHelper.map(parentCategory, SecurityStandardResponse.class);
        SecurityStandardResponse response = mappingHelper.map(item, SecurityStandardResponse.class);
        response.setType(SecurityStandardType.ITEM.name());
        // Load list of child Items of parent Category
//        List<ViolationItem> childrenItems = violationItemRepository.findByViolationCategoryId(parentCategory.getId());
//        List<ViolationItemResponse> children = mappingHelper.mapList(childrenItems, ViolationItemResponse.class);
//        if (children == null) {
//            children = new ArrayList<>();
//        }
        response.setChildren(new ArrayList<>());
        return response;
    }

    @Transactional
    @Override
    public List<Integer> bulkDeleteSecurityStandard(List<ViolationItemDeleteRequest> deleteRequests) {
        List<Integer> deletedIds = new ArrayList<>();
        for (ViolationItemDeleteRequest dto : deleteRequests) {
            if (dto.getId() == null || dto.getType() == null) {
                LinkedHashMap<String, Object> params = new LinkedHashMap<>();
                params.put("id", dto.getId());
                params.put("type", dto.getType());
                throw new BusinessException(ServiceError.INVALID_INPUT, null, params);
            }
            // TODO: process deleted_at time
            if (SecurityStandardType.CATEGORY.name().equalsIgnoreCase(dto.getType())) {
                // delete category
                ViolationCategory category = violationCategoryRepository.findById(dto.getId())
                        .orElseThrow(() -> {
                            LinkedHashMap<String, Object> params = new LinkedHashMap<>();
                            params.put("CategoryId", dto.getId().toString());
                            return new BusinessException(ServiceError.ENTITY_NOT_FOUND, null, params);
                        });
                category.setDeletedAt(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant());
                violationCategoryRepository.save(category);
                // Soft delete all child items of Category
                List<ViolationItem> children = violationItemRepository.findByViolationCategoryId(category.getId());
                for (ViolationItem child : children) {
                    child.setDeletedAt(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant());
//                    child.setDeletedAt(Instant.from(LocalDateTime.now()));
                    violationItemRepository.save(child);
                }
                deletedIds.add(dto.getId());
            } else if (SecurityStandardType.ITEM.name().equalsIgnoreCase(dto.getType())) {
                // Soft delete Item (child) processing
                ViolationItem item = violationItemRepository.findById(dto.getId())
                        .orElseThrow(() -> {
                            LinkedHashMap<String, Object> params = new LinkedHashMap<>();
                            params.put("ItemId", dto.getId().toString());
                            return new BusinessException(ServiceError.ENTITY_NOT_FOUND, null, params);
                        });
                item.setDeletedAt(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant());
                violationItemRepository.save(item);
                deletedIds.add(dto.getId());
            } else {
                LinkedHashMap<String, Object> params = new LinkedHashMap<>();
                params.put("type", dto.getType());
                throw new BusinessException(ServiceError.INVALID_INPUT, null, params);
            }
        }
        return deletedIds;
    }

    private List<Integer> normalizeMinusPoints(List<Integer> minusPoints) {
        if (minusPoints == null || minusPoints.isEmpty()) {
            throw new BusinessException(ServiceError.MINUS_POINT_REQUIRED, null, null);
        }

        List<Integer> mutableList = new ArrayList<>(minusPoints);

        // if list has at less than 5
        while (mutableList.size() < 5) {
            mutableList.add(0);
        }

        // List has at least one element that has no negative value
        mutableList = mutableList.stream().map(point -> (point == null || point < 0) ? 0 : point).collect(Collectors.toList());

        // If there is a subsequent violation but there was no previous violation
        int totalPoints = mutableList.get(0);
        for (int i = 1; i < mutableList.size(); i++) {
            if (mutableList.get(i) > 0 && mutableList.get(i - 1) == 0) {
                LinkedHashMap<String, Object> params = new LinkedHashMap<>();
                params.put("firstOffense", i + 1);
                params.put("secondOffense", i);
                throw new BusinessException(ServiceError.NO_SECOND_OFFENSE_ALLOWED, null, params);
            }
            totalPoints += mutableList.get(i);
        }

        if (totalPoints > 100) {
            throw new BusinessException(ServiceError.INVALID_INPUT, null, null);
        }
        return mutableList;
    }
}
