package com.dx.isecure.secure_service.service.impl;

import com.dx.isecure.common.web.exception.common.BusinessException;
import com.dx.isecure.common.web.exception.common.ServiceError;
import com.dx.isecure.common.web.utils.MappingHelper;
import com.dx.isecure.secure_service.dto.request.SecurityStandardRequest;
import com.dx.isecure.secure_service.entity.ViolationCategory;
import com.dx.isecure.secure_service.entity.ViolationItem;
import com.dx.isecure.secure_service.entity.constant.SecurityStandardType;
import com.dx.isecure.secure_service.repository.ViolationCategoryRepository;
import com.dx.isecure.secure_service.repository.ViolationItemRepository;
import jakarta.servlet.http.HttpServletResponse;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ImportExcelServiceImpl {
    ViolationCategoryServiceimpl violationCategoryServiceimpl;
    ViolationCategoryRepository violationCategoryRepository;
    ViolationItemRepository violationItemRepository;
    MappingHelper mappingHelper;

    @Transactional
    public void importExcel(MultipartFile file, HttpServletResponse response) {
        boolean hasError = false;
        List<SecurityStandardRequest> validCategoryRequests = new ArrayList<>();
        List<SecurityStandardRequest> validItemRequests = new ArrayList<>();
        List<String> validItemMarks = new ArrayList<>();
        Map<Row, String> rowErrors = new LinkedHashMap<>();

        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);
            List<Row> dataRows = new ArrayList<>();
            for (Row row : sheet) {
                // Skip the header row
                if (row.getRowNum() < 2) {
                    continue;
                }
                dataRows.add(row);
            }
//            int rowCount = 0;
            for (Row row : dataRows) {
                // Skip the header row
//                if (row.getRowNum() < 2) {
//                    rowCount++;
//                    continue;
//                }
                // Read data from each cell column
                String code = getCellValueAsString(row.getCell(0));
                String categoryName = getCellValueAsString(row.getCell(1));
                String itemName = getCellValueAsString(row.getCell(2));
                String mark = getCellValueAsString(row.getCell(3));
                String severity = getCellValueAsString(row.getCell(4));
                if (severity != null) {
                    severity = severity.trim().toUpperCase();
                }
                String firstStr = getCellValueAsString(row.getCell(5));
                String secondStr = getCellValueAsString(row.getCell(6));
                String thirdStr = getCellValueAsString(row.getCell(7));
                String fourthStr = getCellValueAsString(row.getCell(8));
                String fifthStr = getCellValueAsString(row.getCell(9));
                String status = getCellValueAsString(row.getCell(10));
                if (status != null) {
                    status = status.trim().toUpperCase();
                }
                List<Integer> minusPoints = parseMinusPoints(firstStr, secondStr, thirdStr, fourthStr, fifthStr);

                // validate data row
                StringBuilder errorBuilder = new StringBuilder();

                if (StringUtils.isBlank(code)) {
                    errorBuilder.append("Code is required. ");
                }
                if (StringUtils.isBlank(categoryName) && StringUtils.isBlank(itemName)) {
                    errorBuilder.append("Category name is required. ");
                }
                // If have Item, have to Mark
                if (!StringUtils.isBlank(itemName) && StringUtils.isBlank(mark)) {
                    errorBuilder.append("For Item, Mark (Category code) is required. ");
                }

                // if have error, save error message rowErrors
                if (!errorBuilder.isEmpty()) {
                    rowErrors.put(row, errorBuilder.toString());
                    hasError = true;
                } else {
                    if (StringUtils.isBlank(mark)) {
                        // If mark is blank, create a new Category
                        if (violationCategoryRepository.findByCode(code).isPresent()) {
                            errorBuilder.append("Category code already exists.");
                        } else {
                            // Create new Category
                            SecurityStandardRequest req = new SecurityStandardRequest();
                            req.setType(SecurityStandardType.CATEGORY.name());
                            req.setCode(code);
                            req.setName(categoryName);
                            req.setStatus(status);
                            validCategoryRequests.add(req);
                        }
                    } else {
                        // Create new Item and associate with Category
                        SecurityStandardRequest itemReq = new SecurityStandardRequest();
                        itemReq.setType(SecurityStandardType.ITEM.name());
                        itemReq.setCode(code);
                        itemReq.setName(itemName);
                        itemReq.setStatus(status);
                        itemReq.setSeverity(severity);
                        itemReq.setMinusPoints(minusPoints);
                        validItemRequests.add(itemReq);
                        validItemMarks.add(mark);
                    }
                }
                // If there is an error in any line, write the error to an Excel file and return the file to the user
                if (hasError) {
                    for (Map.Entry<Row, String> entry : rowErrors.entrySet()) {
                        Row errorRow = entry.getKey();
                        String errorMessage = entry.getValue();
                        Cell errorCell = errorRow.createCell(11, CellType.STRING);
                        errorCell.setCellValue(errorMessage);
                    }
                    response.setHeader("Content-Disposition", "attachment; filename=import_with_errors.xlsx");
                    workbook.write(response.getOutputStream());
                    response.getOutputStream().flush();
                    return;
                }

                // if no error, save validCategoryRequests and validItemRequests to database
                if (!validCategoryRequests.isEmpty()) {
                    List<ViolationCategory> categoryList = mappingHelper.mapList(validCategoryRequests, ViolationCategory.class);
                    violationCategoryRepository.saveAll(categoryList);
                }

                if (!validItemRequests.isEmpty()) {
                    for (int i = 0; i < validItemRequests.size(); i++) {
                        SecurityStandardRequest req = validItemRequests.get(i);
                        String markValue = validItemMarks.get(i);
                        ViolationCategory category = violationCategoryRepository.findByCode(markValue)
                                .orElseThrow(() -> new BusinessException(ServiceError.REQUIRED_CODE_AND_NAME, null,
                                        createParamMap("Mark", "Category with code " + markValue + " not found.")));
                        req.setViolationCategoryId(category.getId());
                    }
                    List<ViolationItem> itemEntities = mappingHelper.mapList(validItemRequests, ViolationItem.class);
                    violationItemRepository.saveAll(itemEntities);
                }
            }
        } catch (Exception e) {
            throw new BusinessException(ServiceError.FILE_PROCESSING_ERROR, e, null);
        }
    }

    private String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return "";
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getLocalDateTimeCellValue().toLocalDate().toString();
                } else {
                    double numericValue = cell.getNumericCellValue();
                    if (numericValue == (long) numericValue) {
                        return String.valueOf((long) numericValue);
                    } else {
                        return String.valueOf(numericValue);
                    }
                }
            case BOOLEAN:
                return Boolean.toString(cell.getBooleanCellValue());
            case FORMULA:
                switch (cell.getCachedFormulaResultType()) {
                    case NUMERIC:
                        if (DateUtil.isCellDateFormatted(cell)) {
                            return cell.getLocalDateTimeCellValue().toLocalDate().toString();
                        } else {
                            double numericValue = cell.getNumericCellValue();
                            if (numericValue == (long) numericValue) {
                                return String.valueOf((long) numericValue);
                            } else {
                                return String.valueOf(numericValue);
                            }
                        }
                    case STRING:
                        return cell.getStringCellValue();
                    case BOOLEAN:
                        return Boolean.toString(cell.getBooleanCellValue());
                    default:
                        return "";
                }
            case BLANK:
            default:
                return "";
        }
    }

    private List<Integer> parseMinusPoints(String first, String second, String third, String fourth, String fifth) {
        List<Integer> minusPoints = new ArrayList<>();
        minusPoints.add(parseIntegerOrDefault(first, 0));
        minusPoints.add(parseIntegerOrDefault(second, 0));
        minusPoints.add(parseIntegerOrDefault(third, 0));
        minusPoints.add(parseIntegerOrDefault(fourth, 0));
        minusPoints.add(parseIntegerOrDefault(fifth, 0));
        return minusPoints;
    }

    private int parseIntegerOrDefault(String value, int defaultValue) {
        if (value == null || value.trim().isEmpty()) {
            return defaultValue;
        }
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    private LinkedHashMap<String, Object> createParamMap(String key, String value) {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put(key, value);
        return params;
    }
}