package com.dx.isecure.secure_service.service;

public interface ViolationCategoryProjection {
    Integer getCategoryId();
    String getCategoryCode();
    String getCategoryName();
    String getCategoryStatus();

    Integer getItemId();
    String getItemCode();
    String getItemName();
    String getSeverity();
    String getMinusPointsRule();
    String getDefinition();
    String getItemStatus();
}
