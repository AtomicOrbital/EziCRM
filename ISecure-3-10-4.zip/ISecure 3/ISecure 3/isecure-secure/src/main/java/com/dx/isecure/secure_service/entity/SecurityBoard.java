package com.dx.isecure.secure_service.entity;

import com.dx.isecure.common.utils.auditaware.AuditEntity;
import com.dx.isecure.secure_service.entity.constant.SecurityBoardType;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDate;
import java.util.UUID;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "SECURITY_BOARD")
@Data
public class SecurityBoard extends AuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "TITLE")
    private String title;

    @Column(name = "TYPE")
    @Enumerated(EnumType.STRING)
    private SecurityBoardType type;

    @Column(name = "PUBLICATION_DATE")
    private LocalDate publicationDate;

    @Column(name = "FILE_GROUP_ID")
    private UUID fileGroupId;
}