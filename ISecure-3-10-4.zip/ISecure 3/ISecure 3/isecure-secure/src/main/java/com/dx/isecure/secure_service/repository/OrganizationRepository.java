package com.dx.isecure.secure_service.repository;

import com.dx.isecure.secure_service.dto.response.OrganizationProjection;
import com.dx.isecure.secure_service.entity.Organization;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface OrganizationRepository extends JpaRepository<Organization, Integer> {
    Optional<Organization> findById(Integer id);

    @EntityGraph(attributePaths = {"orgPic"})
    @Query("SELECT org FROM Organization org WHERE org.deletedAt IS NULL AND org.id IN :id")
    Optional<Organization> getOrganizationById(@Param("id") Integer id);

    @Query(value = "SELECT *, " +
            "NULL CREATED_AT, " +
            "NULL CREATED_BY, " +
            "NULL UPDATED_AT, " +
            "NULL UPDATED_BY, " +
            "NULL DELETED_AT, " +
            "NULL DELETED_BY " +
            "FROM ORGANIZATION_BACKUP " +
            "WHERE ID = (:#{#orgId})", nativeQuery = true)
    Optional<Organization> getOrgInPastPeriodById(Integer orgId);

    @Query(value = """
            SELECT
                org.ID id,
                org.ORG_CODE orgCode,
                e.ID employeeId,
                e.EMPLOYEE_NO employeeNo,
                e.NAME employeeName,
                e.EMAIL employeeEmail,
                e.JOB_TITLE jobTitle,
                e.PHONE_NO phoneNo,
                e.ENTERING_DATE enteringDate,
                org.NAME name,
                org.STATE state,
                org.START_DATE startDate,
                org.END_DATE endDate
            FROM ORGANIZATION org
            LEFT JOIN EMPLOYEE e
            ON e.ID = org.ORG_PIC
            WHERE org.DELETED_AT IS NULL""", nativeQuery = true)
    List<OrganizationProjection> getOrganizationListInCurrentPeriod();

    @Query(value = """
            SELECT
                org.ID id,
                org.ORG_CODE orgCode,
                e.ID employeeId,
                e.EMPLOYEE_NO employeeNo,
                e.NAME employeeName,
                e.EMAIL employeeEmail,
                e.JOB_TITLE jobTitle,
                e.PHONE_NO phoneNo,
                e.ENTERING_DATE enteringDate,
                org.NAME name,
                org.STATE state,
                org.START_DATE startDate,
                org.END_DATE endDate
            FROM ORGANIZATION_BACKUP org
            LEFT JOIN EMPLOYEE e
            ON e.ID = org.ORG_PIC
            WHERE PERIOD_ID = (:#{#periodId})""", nativeQuery = true)
    List<OrganizationProjection> getOrganizationListInPastPeriod(Integer periodId);

    @Query("SELECT org.name, org.id " +
            "FROM Organization org " +
            "WHERE :name IS NOT NULL AND org.name = :name " +
            "AND org.deletedAt IS NULL")
    List<Object[]> findByOrgName(@Param("name") String name);

    @Query("SELECT MAX(org.orgCode) FROM Organization org WHERE org.orgCode LIKE 'ORG%'")
    String findMaxOrgCode();

    boolean existsByOrgCode(String orgCode);
}
