package com.dx.isecure.secure_service.service.impl;

import com.dx.isecure.common.web.exception.EntityNotFoundException;
import com.dx.isecure.common.web.exception.common.BusinessException;
import com.dx.isecure.common.web.exception.common.ServiceError;
import com.dx.isecure.common.web.request.PagingReq;
import com.dx.isecure.common.web.utils.MappingHelper;
import com.dx.isecure.common.web.utils.constant.State;
import com.dx.isecure.secure_service.dto.request.DeleteEmployeeReq;
import com.dx.isecure.secure_service.dto.request.EmployeeReq;
import com.dx.isecure.secure_service.dto.response.EmployeeRes;
import com.dx.isecure.secure_service.entity.Employee;
import com.dx.isecure.secure_service.repository.EmployeeRepository;
import com.dx.isecure.secure_service.service.EmployeeService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class EmployeeServiceImpl implements EmployeeService {
    EmployeeRepository employeeRepository;

    MappingHelper mappingHelper;

    @Override
    public Page<EmployeeRes> getEmployees(String keySearch, State state , PagingReq pagingReq) {
        return employeeRepository.findAllByCriteria(keySearch, state, pagingReq.makePageable());
    }

    public EmployeeRes upsertEmployee(EmployeeReq employeeReq) {
        validateUniqueFields(employeeReq);

        Employee employee;
        if (employeeReq.getId() != null){
            employee = employeeRepository.findById(employeeReq.getId())
                    .filter(e -> e.getDeletedAt() == null)
                    .orElseThrow(() -> new EntityNotFoundException(Employee.class.getSimpleName(), employeeReq.getId().toString()));

            mappingHelper.copyProperties(employeeReq, employee);
        } else {
            employee = mappingHelper.map(employeeReq, Employee.class);
        }

        LocalDate today = LocalDate.now();
        if (employeeReq.getLeavingDate() != null){
         employee.setState(State.IN_ACTIVE);
        } else if (employeeReq.getEnteringDate().isAfter(today)){
            employee.setState(State.IN_ACTIVE);
        } else {
            employee.setState(State.ACTIVE);
        }

        employee = employeeRepository.save(employee);
        return mappingHelper.map(employee, EmployeeRes.class);
    }

    public void deleteEmployees(DeleteEmployeeReq deleteEmployeeReq) {
        if (deleteEmployeeReq.getIds() == null || deleteEmployeeReq.getIds().isEmpty()){
            throw new EntityNotFoundException(Employee.class.getSimpleName(), deleteEmployeeReq.getIds().toString());
        }

        List<Employee> employees = employeeRepository.findAllById(deleteEmployeeReq.getIds());
        Set<Integer> foundIds = employees.stream().map(Employee::getId).collect(Collectors.toSet());

        List<Integer> notFoundIds = deleteEmployeeReq.getIds().stream()
                .filter(id -> !foundIds.contains(id))
                .toList();

        if (!notFoundIds.isEmpty()) {
            throw new EntityNotFoundException(Employee.class.getSimpleName(), notFoundIds.toString());
        }

        employeeRepository.updateDeletedAtByIds(Instant.now(), deleteEmployeeReq.getIds());
    }

    private void validateUniqueFields(EmployeeReq employeeReq) {
        Integer id = employeeReq.getId();

        if (employeeReq.getEmployeeNo() != null && employeeRepository.existsByEmployeeNo(employeeReq.getEmployeeNo())) {
            Employee existing = employeeRepository.findByEmployeeNo(employeeReq.getEmployeeNo()).orElse(null);
            if (existing != null && (id == null || !id.equals(existing.getId()))) {
                throw new BusinessException(ServiceError.DUPLICATE_EMPLOYEE_NO, null, null);
            }
        }

        if (employeeReq.getEmail() != null && employeeRepository.existsByEmail(employeeReq.getEmail())) {
            Employee existing = employeeRepository.findByEmail(employeeReq.getEmail()).orElse(null);
            if (existing != null && (id == null || !id.equals(existing.getId()))) {
                throw new BusinessException(ServiceError.DUPLICATE_EMPLOYEE_EMAIL, null, null);
            }
        }

        if (employeeReq.getPhoneNo() != null && employeeRepository.existsByPhoneNo(employeeReq.getPhoneNo())) {
            Employee existing = employeeRepository.findByPhoneNo(employeeReq.getPhoneNo()).orElse(null);
            if (existing != null && (id == null || !id.equals(existing.getId()))) {
                throw new BusinessException(ServiceError.DUPLICATE_EMPLOYEE_PHONE, null, null);
            }
        }
    }
}
