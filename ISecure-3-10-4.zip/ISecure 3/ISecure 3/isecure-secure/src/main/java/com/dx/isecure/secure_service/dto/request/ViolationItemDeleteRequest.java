package com.dx.isecure.secure_service.dto.request;

import lombok.Data;

@Data
public class ViolationItemDeleteRequest {
    private Integer id;
    private String type;
}
