package com.dx.isecure.secure_service.util;

import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.util.List;

public class CustomPage<T> extends PageImpl<T> {
    private final long forcedTotal;

    public CustomPage(List<T> content, Pageable pageable, long total) {
        super(content, pageable, total);
        this.forcedTotal = total;
    }

    @Override
    public long getTotalElements(){
        return forcedTotal;
    }
}
