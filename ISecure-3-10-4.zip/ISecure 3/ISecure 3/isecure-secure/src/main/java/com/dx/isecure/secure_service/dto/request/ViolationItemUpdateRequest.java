package com.dx.isecure.secure_service.dto.request;

import lombok.Data;

import java.util.List;

@Data
public class ViolationItemUpdateRequest {
    private Integer id;
    private String code;
    private String name;
    private String severity;
    private String status;
    private List<Integer> minusPoints;
    private String definition;
}
