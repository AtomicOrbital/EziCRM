package com.dx.isecure.secure_service.dto;

import com.dx.isecure.common.web.utils.constant.State;
import com.dx.isecure.secure_service.entity.constant.Severity;
import lombok.Data;

@Data
public class ViolationItemDto {
    private Integer id;
    private String code;
    private String name;
    private Severity severity;
    private State status;
    private String minusPointsRule;
    private String definition;
    private ViolationCategoryDto violationCategoryDto;
}
