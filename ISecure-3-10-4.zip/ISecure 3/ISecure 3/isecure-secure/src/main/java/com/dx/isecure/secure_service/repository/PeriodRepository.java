package com.dx.isecure.secure_service.repository;

import com.dx.isecure.secure_service.entity.Period;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.Optional;

public interface PeriodRepository extends JpaRepository<Period, Integer> {
    Optional<Period> findByPeriodStartDateAndPeriodEndDate(LocalDate startDate, LocalDate endDate);

    @Query("FROM Period WHERE (:date) BETWEEN periodStartDate AND periodEndDate")
    Optional<Period> findBySpecificDate(LocalDate date);
}
