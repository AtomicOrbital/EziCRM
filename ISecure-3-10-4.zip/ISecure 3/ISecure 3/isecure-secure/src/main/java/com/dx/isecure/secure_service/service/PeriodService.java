package com.dx.isecure.secure_service.service;

import com.dx.isecure.secure_service.dto.PeriodDto;

import java.util.List;

public interface PeriodService {
    List<PeriodDto> getPeriodList();
}
