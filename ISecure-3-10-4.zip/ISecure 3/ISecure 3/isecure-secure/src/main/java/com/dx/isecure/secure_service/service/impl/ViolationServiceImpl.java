package com.dx.isecure.secure_service.service.impl;

import com.dx.isecure.common.client.storage.IStorageClient;
import com.dx.isecure.common.client.storage.dto.GroupFileReq;
import com.dx.isecure.common.web.exception.EntityNotFoundException;
import com.dx.isecure.common.web.exception.common.BusinessException;
import com.dx.isecure.common.web.exception.common.ServiceError;
import com.dx.isecure.common.web.request.PagingReq;
import com.dx.isecure.common.web.utils.MappingHelper;
import com.dx.isecure.common.web.utils.constant.State;
import com.dx.isecure.secure_service.dto.EmployeeDto;
import com.dx.isecure.secure_service.dto.PeriodDto;
import com.dx.isecure.secure_service.dto.ViolationItemDto;
import com.dx.isecure.secure_service.dto.request.CheckNthViolationReq;
import com.dx.isecure.secure_service.dto.request.RegisterViolationReq;
import com.dx.isecure.secure_service.dto.request.ViolationCriteria;
import com.dx.isecure.secure_service.dto.response.CheckNthViolationRes;
import com.dx.isecure.secure_service.dto.response.ViolationDetailRes;
import com.dx.isecure.secure_service.dto.response.ViolationListProjection;
import com.dx.isecure.secure_service.dto.response.ViolationListRes;
import com.dx.isecure.secure_service.entity.*;
import com.dx.isecure.secure_service.entity.constant.DefaultValue;
import com.dx.isecure.secure_service.repository.*;
import com.dx.isecure.secure_service.service.ViolationService;
import com.dx.isecure.secure_service.util.BusinessUtil;
import com.dx.isecure.secure_service.util.MapperResponseUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.internal.Pair;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
@RequiredArgsConstructor
public class ViolationServiceImpl implements ViolationService {
    private final OrganizationRepository organizationRepository;
    private final OrgEmployeeRepository orgEmployeeRepository;
    private final ViolationCategoryRepository violationCategoryRepository;
    private final EmployeeRepository employeeRepository;
    private final EmployeeSecurityRepository employeeSecurityRepository;
    private final PeriodRepository periodRepository;
    private final ViolationItemRepository violationItemRepository;
    private final ViolationRepository violationRepository;
    private final MappingHelper mappingHelper;
    private final IStorageClient storageClient;

    @Transactional
    @Override
    public CheckNthViolationRes checkNthSameViolation(CheckNthViolationReq req) {

        var employee = employeeRepository.findByIdAndState(req.getEmployeeId(), State.ACTIVE)
                .orElseThrow(() -> new EntityNotFoundException(
                        Employee.class.getSimpleName(),
                        req.getEmployeeId().toString())
                );

        var violationItem = violationItemRepository.findByIdAndStatus(req.getViolationItemId(), State.ACTIVE)
                .orElseThrow(() -> new EntityNotFoundException(
                        ViolationItem.class.getSimpleName(),
                        req.getViolationItemId().toString())
                );

        var period = periodRepository.findBySpecificDate(LocalDate.now())
                .orElseGet(this::createDefaultPeriod);
        var employeeSecurity = resolveEmployeeSecurity(employee, period);

        Integer numOfViolation = violationRepository.countViolationEmployeeByItem(employeeSecurity.getId(), violationItem.getId());
        Integer nthViolation = numOfViolation + 1;
        Integer minusPoints = calculateMinusPoints(nthViolation, violationItem.getMinusPointsRule());

        return CheckNthViolationRes.builder()
                .employee(mappingHelper.map(employee, EmployeeDto.class))
                .violationItem(mappingHelper.map(violationItem, ViolationItemDto.class))
                .period(mappingHelper.map(period, PeriodDto.class))
                .nthViolation(nthViolation)
                .minusPoint(minusPoints)
                .build();
    }

    @Transactional
    @Override
    public Integer registerViolation(RegisterViolationReq req) {
        if (req.getEvidences().isEmpty())
            throw new BusinessException(ServiceError.EVIDENCES_IS_EMPTY, null, null);

        Employee employee = employeeRepository.findByIdAndState(req.getEmployeeId(), State.ACTIVE)
                .orElseThrow(() -> new EntityNotFoundException(
                        Employee.class.getSimpleName(),
                        req.getEmployeeId().toString())
                );

        ViolationItem violationItem = violationItemRepository.findByIdAndStatus(req.getViolationItemId(), State.ACTIVE)
                .orElseThrow(() -> new EntityNotFoundException(
                        ViolationItem.class.getSimpleName(),
                        req.getViolationItemId().toString())
                );

        orgEmployeeRepository.getInCurrentPeriodByEmployee(employee.getId())
                .orElseThrow(() -> new BusinessException(ServiceError.EMPLOYEE_DONT_HAVE_ORG, null, null));

        Period period = periodRepository.findBySpecificDate(LocalDate.now())
                .orElseGet(this::createDefaultPeriod);

        EmployeeSecurity employeeSecurity = resolveEmployeeSecurity(employee, period);
        Integer numOfViolation = violationRepository.countViolationEmployeeByItem(employeeSecurity.getId(), violationItem.getId());
        Integer nthViolation = numOfViolation + 1;
        Integer minusPoints = calculateMinusPoints(nthViolation, violationItem.getMinusPointsRule());

        UUID fileGroupId = UUID.randomUUID();
        var violation = Violation.builder()
                .violationItem(violationItem)
                .employeeSecurity(employeeSecurity)
                .nthViolation(nthViolation)
                .minusPoints(minusPoints)
                .description(req.getDescription())
                .fileGroupId(fileGroupId.toString())
                .build();

        employeeSecurity.setTotalViolation(employeeSecurity.getTotalViolation() + 1);
        employeeSecurity.setSecurityPoint(employeeSecurity.getSecurityPoint() - minusPoints.doubleValue());

        employeeSecurityRepository.save(employeeSecurity);
        violationRepository.save(violation);

        // Call api update file group storage service
        GroupFileReq groupFileReq = GroupFileReq.builder()
                .fileGroupId(fileGroupId.toString())
                .fileIds(req.getEvidences().stream().map(UUID::toString).toList())
                .build();
        storageClient.groupFiles(groupFileReq);

        return violation.getId();
    }

    @Override
    public Page<ViolationListRes> getViolationList(ViolationCriteria violationCriteria, PagingReq pagingReq) {
        Period period = resolvePeriod(violationCriteria.getPeriodId());
        violationCriteria.setPeriodId(period.getId());

        // TODO: Check Time join time left condition of backup table
        Pageable pageable = pagingReq.makePageable();
        Page<ViolationListProjection> violationProjections = Boolean.TRUE.equals(BusinessUtil.isCurrentPeriod(period))
                ? violationRepository.getViolationListInCurrentPeriod(violationCriteria, pageable)
                : violationRepository.getViolationListForPastPeriod(violationCriteria, pageable);

        return MapperResponseUtil.convertToViolationListRes(violationProjections);
    }

    @Override
    public ViolationDetailRes getViolationDetail(Integer violationId) {
        Violation violation = getEntityOrThrow(
                violationRepository.getDetailById(violationId),
                Violation.class,
                violationId.toString()
        );

        Period period = violation.getEmployeeSecurity().getPeriod();
        Employee employee = violation.getEmployeeSecurity().getEmployee();
        boolean isCurrentPeriod = BusinessUtil.isCurrentPeriod(period);

        ViolationItem violationItem = isCurrentPeriod
                ? violation.getViolationItem()
                : getEntityOrThrow(
                violationItemRepository.getItemInPastPeriodById(violation.getViolationItem().getId(), period.getId()),
                ViolationItem.class,
                violation.getViolationItem().getId().toString()
        );

        ViolationCategory category = isCurrentPeriod
                ? violationItem.getViolationCategory()
                : getEntityOrThrow(
                violationCategoryRepository.getCategoryInPastPeriodById(violationItem.getViolationCategory().getId(), period.getId()),
                ViolationCategory.class,
                violationItem.getViolationCategory().getId().toString()
        );

        OrgEmployee orgEmployee = getEntityOrThrow(
                orgEmployeeRepository.getInPeriodByEmployeeViolation(violation.getCreatedAt(), employee.getId()),
                OrgEmployee.class,
                violation.getId().toString()
        );

        Organization organization = isCurrentPeriod
                ? orgEmployee.getOrganization()
                : getEntityOrThrow(
                organizationRepository.getOrgInPastPeriodById(orgEmployee.getOrganization().getId()),
                Organization.class,
                orgEmployee.getOrganization().getId().toString()
        );

        EmployeeDto employeeDto = mappingHelper.map(employee, EmployeeDto.class);
        employeeDto.setOrganization(organization.getName());

        ViolationDetailRes response = mappingHelper.map(violation, ViolationDetailRes.class);
        response.setViolationTime(violation.getCreatedAt());
        response.setViolationItem(violationItem.getName());
        response.setSeverity(violationItem.getSeverity());
        response.setCategory(category.getName());
        response.setEmployee(employeeDto);

        // get reporter user
        EmployeeDto reporter = new EmployeeDto();
        reporter.setName(violation.getCreatedBy());
        response.setReportBy(reporter);

        // call api storage to get evidences
        response.setEvidences(storageClient.getFilesByGroupId(violation.getFileGroupId()));

        return response;
    }

    private <T> T getEntityOrThrow(Optional<T> optional, Class<T> entityClass, String id) {
        return optional.orElseThrow(() -> new EntityNotFoundException(
                entityClass.getSimpleName(),
                id
        ));
    }

    private EmployeeSecurity resolveEmployeeSecurity(Employee employee, Period period) {
        return employeeSecurityRepository.findByEmployeeIdAndPeriodId(employee.getId(), period.getId())
                .orElseGet(() -> {
                    EmployeeSecurity newEmployeeSecurity = EmployeeSecurity.builder()
                            .employee(employee)
                            .period(period)
                            .securityPoint(DefaultValue.SECURITY_POINT)
                            .totalViolation(DefaultValue.TOTAL_VIOLATION)
                            .build();
                    return employeeSecurityRepository.save(newEmployeeSecurity);
                });
    }

    private Period createDefaultPeriod() {
        Pair<LocalDate, LocalDate> dateRange = BusinessUtil.getDateRangeFromSpecificDate(LocalDate.now());
        Period newPeriod = Period.builder()
                .periodStartDate(dateRange.getLeft())
                .periodEndDate(dateRange.getRight())
                .build();
        return periodRepository.save(newPeriod);
    }

    private Integer calculateMinusPoints(Integer nthViolation, String minusPointsRule) {
        List<Integer> minusPointRules = Arrays.stream(minusPointsRule.split("/"))
                .map(Integer::parseInt)
                .toList();

        int index = Math.min(nthViolation - 1, minusPointRules.size() - 1);
        Integer minusPoints = minusPointRules.get(index);

        while (minusPoints <= 0 && index > 0) {
            minusPoints = minusPointRules.get(index--);
        }
        return minusPoints;
    }

    private Period resolvePeriod(Integer periodId) {
        if (periodId == null) {
            return periodRepository.findBySpecificDate(LocalDate.now())
                    .orElseGet(this::createDefaultPeriod);
        }
        return periodRepository.findById(periodId)
                .orElseThrow(() -> new EntityNotFoundException(Period.class.getSimpleName(), periodId.toString()));
    }
}
