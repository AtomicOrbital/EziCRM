package com.dx.isecure.secure_service.entity.constant;

import lombok.Getter;

@Getter
public enum SecurityStandardType {
    CATEGORY,
    ITEM;
}
