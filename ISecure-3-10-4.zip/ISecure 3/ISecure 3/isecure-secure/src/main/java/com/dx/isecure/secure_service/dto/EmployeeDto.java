package com.dx.isecure.secure_service.dto;

import com.dx.isecure.common.web.utils.constant.State;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDto {
    private Integer id;
    private String employeeNo;
    private String name;
    private String email;
    private String jodTitle;
    private String phoneNo;
    private LocalDate enteringDate;
    private State state;
    private String accountId;
    private String organization;
}
