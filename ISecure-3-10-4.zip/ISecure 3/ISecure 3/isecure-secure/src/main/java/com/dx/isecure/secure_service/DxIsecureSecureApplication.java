package com.dx.isecure.secure_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.*"})
public class DxIsecureSecureApplication {

    public static void main(String[] args) {
        SpringApplication.run(DxIsecureSecureApplication.class, args);
    }

}
