package com.dx.isecure.secure_service.util;

import com.dx.isecure.secure_service.entity.Period;
import org.modelmapper.internal.Pair;

import java.time.LocalDate;
import java.time.Month;

public class BusinessUtil {

    private BusinessUtil() {
        throw new IllegalStateException("Utility class");
    }

    public static Pair<LocalDate, LocalDate> getDateRangeFromSpecificDate(LocalDate date) {
        int year = date.getYear();
        int month = date.getMonthValue();

        LocalDate startDate;
        LocalDate endDate;

        if (month <= 6) {
            startDate = LocalDate.of(year, Month.JANUARY, 1);
            endDate = LocalDate.of(year, Month.JUNE, 1);
        } else {
            startDate = LocalDate.of(year, Month.JULY, 1);
            endDate = LocalDate.of(year, Month.DECEMBER, 1);
        }

        return Pair.of(startDate, endDate);
    }

    public static Boolean isCurrentPeriod(Period period) {
        LocalDate startDate = period.getPeriodStartDate();
        LocalDate endDate = period.getPeriodEndDate();
        LocalDate currentDate = LocalDate.now();
        return !currentDate.isBefore(startDate) && !currentDate.isAfter(endDate);
    }
}
