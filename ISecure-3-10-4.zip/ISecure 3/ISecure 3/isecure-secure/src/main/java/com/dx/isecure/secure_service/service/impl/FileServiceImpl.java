package com.dx.isecure.secure_service.service.impl;

import com.dx.isecure.secure_service.service.FileService;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

import static com.dx.isecure.secure_service.constant.ExcelFileSrc.SECURITY_STANDARD_TEMPLATE_PATH;

@Service
public class FileServiceImpl implements FileService {

    @Override
    public ResponseEntity<Resource> downloadFile(String filename) {
        Resource resource = new ClassPathResource(SECURITY_STANDARD_TEMPLATE_PATH + filename);
        try {
            InputStreamResource inputStreamResource = new InputStreamResource(resource.getInputStream());
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(inputStreamResource);
        } catch (IOException e) {
            throw new RuntimeException("Error while downloading file", e);
        }
    }

    @Override
    public String uploadFile(MultipartFile file) {
        return "";
    }

    @Override
    public ResponseEntity<Resource> exportFile(String filename) {
        return null;
    }
}
