package com.dx.isecure.common.client.storage.dto;

import lombok.Data;

@Data
public class AttachmentDto {
    private String fileId;
    private String name;
    private String url;
}
