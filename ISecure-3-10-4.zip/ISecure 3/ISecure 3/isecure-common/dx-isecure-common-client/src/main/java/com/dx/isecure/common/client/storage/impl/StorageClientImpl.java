package com.dx.isecure.common.client.storage.impl;

import com.dx.isecure.common.client.AbstractClient;
import com.dx.isecure.common.client.storage.IStorageClient;
import com.dx.isecure.common.client.storage.dto.AttachmentDto;
import com.dx.isecure.common.client.storage.dto.GroupFileReq;
import com.dx.isecure.common.web.exception.common.BusinessException;
import com.dx.isecure.common.web.exception.common.ServiceError;
import com.dx.isecure.common.web.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.Objects;

@Service
@Slf4j
public class StorageClientImpl extends AbstractClient implements IStorageClient {

    private static final String PATH_MAKE_FILE_GROUP = "/file-organizer/group-files";
    private static final String PATH_GET_FILES_BY_GROUP = "/file-organizer/by-group/{groupId}";

    @Value("${client-service.storage.uri:}")
    private String uri;

    public StorageClientImpl(@Qualifier("clientTemplate") RestTemplate restTemplate) {
        super(restTemplate);
    }

    @Retryable(retryFor = Exception.class, maxAttempts = 3, backoff = @Backoff(delay = 300))
    @Override
    public Object groupFiles(GroupFileReq request) {
        try {
            HttpHeaders headers = createAuthHeaders();
            var httpEntity = new HttpEntity<>(request, headers);
            URI uriObj = UriComponentsBuilder.fromHttpUrl(uri)
                    .path(PATH_MAKE_FILE_GROUP)
                    .build().toUri();
            ParameterizedTypeReference<Response> parameterizedTypeReference = new ParameterizedTypeReference<>() {
            };
            return Objects.requireNonNull(restTemplate.exchange(uriObj, HttpMethod.POST, httpEntity, parameterizedTypeReference).getBody()).getData();
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new BusinessException(ServiceError.GROUP_FILE_ERROR, null, null);
        }
    }

    @Retryable(retryFor = Exception.class, maxAttempts = 3, backoff = @Backoff(delay = 300))
    @Override
    public List<AttachmentDto> getFilesByGroupId(String groupId) {
        try {
            HttpHeaders headers = createAuthHeaders();
            var httpEntity = new HttpEntity<>(headers);
            URI uriObj = UriComponentsBuilder.fromHttpUrl(uri)
                    .path(PATH_GET_FILES_BY_GROUP)
                    .buildAndExpand(groupId)
                    .toUri();
            ParameterizedTypeReference<Response> responseType = new ParameterizedTypeReference<>() {
            };

            Response response = restTemplate.exchange(
                    uriObj,
                    HttpMethod.GET,
                    httpEntity,
                    responseType
            ).getBody();

            if (response == null || response.getData() == null) {
                log.warn("No files found for groupId: {}", groupId);
                return List.of();
            }
            return (List<AttachmentDto>) response.getData();

        } catch (Exception ex) {
            log.error("Error fetching files for groupId: {}. Message: {}", groupId, ex.getMessage(), ex);
            throw new BusinessException(ServiceError.GROUP_FILE_ERROR, null, null);
        }
    }
}



