package com.dx.isecure.common.utils.auditaware;
import lombok.Data;

import java.time.Instant;
@Data
public class AuditDomain {

    private String createdBy;
    // @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant createdAt;

    private String updatedBy;
    // @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant updatedAt;

    private String deletedBy;
    private Instant deletedAt;
}
