package com.dx.isecure.common.web.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor(access = AccessLevel.PROTECTED)
public class Response {

    protected Boolean result;
    protected Integer code;
    protected String message;
    protected Object data;

    public static Response of(Boolean status, Integer code, String message, Object data) {
        return Response.builder()
                .result(status)
                .code(code)
                .message(message)
                .data(data)
                .build();
    }

    public static Response of(Boolean status, ServiceMessage serviceMessage, Object data) {
        return Response.builder()
                .result(status)
                .code(serviceMessage.getCode())
                .message(serviceMessage.getMessageKey())
                .data(data)
                .build();
    }

}
