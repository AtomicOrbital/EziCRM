package com.dx.isecure.common.web.exception.common;

import lombok.Getter;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Getter
public enum ServiceError {
    INVALID_TOKEN(401000, "err.authorize.invalid-token"),
    INVALID_TOKEN_FORMAT(401001, "err.authorize.invalid-token-format"),
    TOKEN_INFO_INCORRECT(401002, "err.authorize.token-info-incorrect"),
    SESSION_EXPIRED(401003, "err.authorize.session-expired"),
    CMN_ACCESS_DENIED(401004, "err.authorize.access-denied"),
    CHANGE_PW_REQUIRED(401005, "err.authorize.change-pw-required"),
    USERNAME_OR_PW_IN_CORRECT(401006, "err.authorize.username-or-pw-in-correct"),
    TOKEN_EXPIRED(401007, "err.authorize.token-expired"),
    NEW_PASSWORD_MATCHES_OLD(401008, "err.authorize.new-password-matches-old"),

    CMN_INVALID_PARAM(400000, "err.api.invalid-param"),
    CMN_MESSAGE_NOT_READABLE(400001, "err.api.message-not-readable"),

    ENTITY_NOT_FOUND(404000, "err.api.entity-not-found"),
    CMN_HTTP_METHOD_NOT_SUPPORT(405000, "err.api.http-method-not-support"),
    CMN_MEDIA_TYPE_NOT_SUPPORT(415000, "err.api.media-type-not-support"),

    // Storage service error message
    FILE_EMPTY(400002, "err.api.file-empty"),
    FILE_TYPE_NOT_SUPPORT(400003, "err.api.file-type-not-support"),
    UPLOAD_FILE_FAIL(400004, "err.api.upload-file-fail"),
    GROUP_FILE_ERROR(400005, "err.api.group-file-error"),
    MISSING_REQUEST_PART(400006, "err.api.missing-request-param"),

    // Business error
    EVIDENCES_IS_EMPTY(400007, "err.api.evidences-is-empty"),
    EMPLOYEE_DONT_HAVE_ORG(400008, "err.api.employee-dont-have-org"),

    UNEXPECTED_EXCEPTION(500000, "err.sys.unexpected-exception"),

    INACTIVE_EMPLOYEE_STATUS(600000, "err.api.inactive-employee-status"),
    EMPLOYEE_HAD_ORG(600001, "err.api.employee-had-org"),

    DUPLICATE_EMPLOYEE_NO(600002, "err.api.duplicate-employee-no"),
    DUPLICATE_EMPLOYEE_EMAIL(600003, "err.api.duplicate-employee-email"),
    DUPLICATE_EMPLOYEE_PHONE(600004, "err.api.duplicate-employee-phone"),

    DUPLICATE_ENTRY(415001, "err.api.duplicate-entry"),
    REQUIRED_VIOLATION_CATEGORY(415002, "err.api.required-violation-category"),
    INVALID_INPUT(415003, "err.api.invalid-input"),
    NO_SECOND_OFFENSE_ALLOWED(415004, "err.api.no-second-offense-allowed"),
    MINUS_POINT_REQUIRED(415005, "err.api.no-minus_point_required"),
    REQUIRED_CODE_AND_NAME(415006, "err.api.no-required_code_and_name"),

    DUPLICATE_ORGANIZATION_CODE(600005, "err.api.duplicate-organization-code"),
    DUPLICATE_ORGANIZATION_NAME(600006, "err.api.duplicate-organization-name"),

    PARENT_ORG_NOT_FOUND(600007, "err.api.parent-org-not-found");

    ServiceError(int errCode, String messageKey) {
        this.errCode = errCode;
        this.messageKey = messageKey;
    }

    private static final Map<String, ServiceError> ERROR_MAP = new HashMap<>();

    static {
        for (ServiceError e : values()) {
            ERROR_MAP.put(e.getMessageKey(), e);
        }
    }

    private final int errCode;
    private final String messageKey;

    public static ServiceError getByMessageKey(String messageKey) {
        return Optional.ofNullable(ERROR_MAP.get(messageKey))
                .orElse(UNEXPECTED_EXCEPTION);
    }

}
