package com.dx.isecure.common.web.exception;

import com.dx.isecure.common.web.exception.common.BusinessException;
import com.dx.isecure.common.web.exception.common.ServiceError;
import com.dx.isecure.common.web.exception.common.SysException;
import com.dx.isecure.common.web.response.ErrorResponse;
import com.dx.isecure.common.web.response.Response;
import com.dx.isecure.common.web.response.ResponseUtils;
import com.dx.isecure.common.web.utils.I18nMessageHelper;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
//import org.springframework.security.access.AccessDeniedException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.multipart.support.MissingServletRequestPartException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


@Slf4j
@ControllerAdvice
@RequiredArgsConstructor
public class ExceptionControllerAdvice {

    private final I18nMessageHelper messageHelper;

    @ExceptionHandler({ConstraintViolationException.class})
    public ResponseEntity<Response> validateErrorHandler(ConstraintViolationException e) {
        String errMsg = messageHelper.getErrorMessage(ServiceError.CMN_INVALID_PARAM.getMessageKey());
        Set<ConstraintViolation<?>> set = e.getConstraintViolations();
        StringBuilder propertyErrMsg = new StringBuilder();
        for (ConstraintViolation<?> next : set) {
            propertyErrMsg.append(next.getMessage()).append(", ");
        }
        return ResponseUtils.badRequest(
                ErrorResponse.of(ServiceError.CMN_INVALID_PARAM, errMsg + ": " + propertyErrMsg));
    }

    @ExceptionHandler({MethodArgumentNotValidException.class})
    public ResponseEntity<Response> notValidArgumentErrorHandler(MethodArgumentNotValidException e) {
        String errMsg = messageHelper.getErrorMessage(ServiceError.CMN_INVALID_PARAM.getMessageKey());
        List<String> errors = e.getBindingResult().getFieldErrors()
                .stream().map(FieldError::getDefaultMessage)
                .toList();

        return ResponseUtils.badRequest(
                ErrorResponse.of(ServiceError.CMN_INVALID_PARAM, errMsg, getErrorsMap(errors)));
    }

    @ExceptionHandler({BindException.class})
    public ResponseEntity<Response> invalidRequestParamErrorHandler(BindException e) {
        String errMsg = messageHelper.getErrorMessage(ServiceError.CMN_INVALID_PARAM.getMessageKey());
        return ResponseUtils.badRequest(
                ErrorResponse.of(ServiceError.CMN_INVALID_PARAM, errMsg + ": " + e.getLocalizedMessage()));
    }

//    @ExceptionHandler({AccessDeniedException.class})
//    public ResponseEntity<Response> accessDeniedErrorHandler(AccessDeniedException e) {
//        log.error("access denied", e);
//        String errMsg = messageHelper.getErrorMessage(ServiceError.CMN_ACCESS_DENIED.getMessageKey());
//        return ResponseUtils.unauthorized(ErrorResponse.of(ServiceError.CMN_ACCESS_DENIED.getMessageKey(), errMsg));
//    }


    @ExceptionHandler({HttpRequestMethodNotSupportedException.class})
    public ResponseEntity<Response> methodNotSupportErrorHandler(HttpRequestMethodNotSupportedException e) {
        log.error("Http method not support exception: {}", e.getMessage());
        String errMsg = messageHelper.getErrorMessage(ServiceError.CMN_HTTP_METHOD_NOT_SUPPORT.getMessageKey(), e.getMethod(), ArrayUtils.toString(e.getSupportedMethods()));
        return ResponseUtils.methodNotSupported(ErrorResponse.of(ServiceError.CMN_HTTP_METHOD_NOT_SUPPORT, errMsg));
    }

    @ExceptionHandler({HttpMediaTypeNotSupportedException.class})
    public ResponseEntity<Response> mediaTypeNotSupportedErrorHandler(HttpMediaTypeNotSupportedException e) {
        log.error("Http media type not support exception: {}", e.getMessage());
        String errMsg = messageHelper.getErrorMessage(ServiceError.CMN_MEDIA_TYPE_NOT_SUPPORT.getMessageKey(), e.getContentType());
        return ResponseUtils.mediaTypeNotSupported(ErrorResponse.of(ServiceError.CMN_MEDIA_TYPE_NOT_SUPPORT, errMsg));
    }

    @ExceptionHandler({HttpMessageNotReadableException.class})
    public ResponseEntity<Response> httpMessageNotReadableExceptionHandler(HttpMessageNotReadableException e) {
        log.error("Http message not readable exception: {}", e.getMessage());
        String errMsg = messageHelper.getErrorMessage(ServiceError.CMN_MESSAGE_NOT_READABLE.getMessageKey(), e.getMostSpecificCause().getLocalizedMessage());
        return ResponseUtils.badRequest(ErrorResponse.of(ServiceError.CMN_MESSAGE_NOT_READABLE, errMsg));
    }

    @ExceptionHandler({MissingServletRequestPartException.class})
    public ResponseEntity<Response> missingServletRequestPartExceptionHandler(MissingServletRequestPartException e) {
        log.error("Missing required part in request: {}", e.getMessage());
        String errMsg = messageHelper.getErrorMessage(ServiceError.MISSING_REQUEST_PART.getMessageKey(), e.getRequestPartName());
        return ResponseUtils.badRequest(
                ErrorResponse.of(ServiceError.MISSING_REQUEST_PART, errMsg));
    }

    @ExceptionHandler({BusinessException.class})
    public ResponseEntity<Response> applicationErrorHandler(BusinessException e) {
        log.warn("Business Exception", e);
        String errMsg = messageHelper.getErrorMessage(e.getErr().getMessageKey(), e.getParams().values().toArray());
        return ResponseUtils.notSuccess(
                HttpStatus.BAD_REQUEST,
                ErrorResponse.of(e.getErr(), errMsg, e.getParams()));
    }

    @ExceptionHandler({Exception.class, SysException.class})
    public ResponseEntity<Response> unknownErrorHandler(Exception e) {
        log.error("Unexpected Exception", e);
        String errMsg = messageHelper.getErrorMessage(ServiceError.UNEXPECTED_EXCEPTION.getMessageKey());
        return ResponseUtils.internalErr(ErrorResponse.of(ServiceError.UNEXPECTED_EXCEPTION, errMsg));
    }

    private Map<String, Object> getErrorsMap(List<String> errors) {
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("errors", errors);
        return errorResponse;
    }

}
