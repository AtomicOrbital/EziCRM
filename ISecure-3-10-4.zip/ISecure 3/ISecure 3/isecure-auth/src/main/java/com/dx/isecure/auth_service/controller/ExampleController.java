package com.dx.isecure.auth_service.controller;

import com.dx.isecure.common.utils.fake_data.User;
import com.dx.isecure.common.utils.fake_data.UserInfoGenerator;
import com.dx.isecure.common.web.response.ResponseUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/example")
@CrossOrigin("*")
public class ExampleController {

    @GetMapping("/fake-data")
    public ResponseEntity<?> fakeData() throws IOException {
        List<User> users = new ArrayList<>();

        LocalDate start = LocalDate.of(1989, 1, 1);
        LocalDate end = LocalDate.of(2004, 1, 1);

        for (int i = 0; i < 50; i++) {
            String fullName = UserInfoGenerator.generateFullName();
            users.add(new User(
                    null,
                    fullName,
                    fullName.replaceAll(" ", "").replaceAll("[^\\x20-\\x7e]", "") + UserInfoGenerator.generateRandomEmail(),
                    Date.from(UserInfoGenerator.between(start, end).atStartOfDay(ZoneId.systemDefault()).toInstant()),
                    UserInfoGenerator.generateRandomGender(),
                    UserInfoGenerator.generateRandomPhoneNumber(),
                    UserInfoGenerator.generateRandomAddress(),
                    UserInfoGenerator.generateRandomStatus()
            ));
        }
        return ResponseUtils.ok(users);
    }
}
